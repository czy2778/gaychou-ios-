import Foundation

enum APIError: LocalizedError {
    case server(String)
    case network(String)
    case decoding

    var errorDescription: String? {
        switch self {
        case .server(let message): return message
        case .network(let message): return message
        case .decoding: return "服务器返回了无法识别的数据"
        }
    }
}

/// 与网站共用同一套后端：https://aly.gaychou.top/api.php
/// 鉴权使用 Bearer token（由 r=login 下发），与网页 session 等价。
final class APIClient {
    static let shared = APIClient()

    private let base = URL(string: "https://aly.gaychou.top")!
    private let session: URLSession
    private let decoder: JSONDecoder

    private let tokenKey = "gaychou.token"

    private init() {
        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 40
        configuration.httpCookieStorage = HTTPCookieStorage.shared
        configuration.httpShouldSetCookies = true
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        session = URLSession(configuration: configuration)

        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        self.decoder = decoder
    }

    // MARK: - Token

    var token: String? {
        get { UserDefaults.standard.string(forKey: tokenKey) }
        set {
            if let newValue, !newValue.isEmpty {
                UserDefaults.standard.set(newValue, forKey: tokenKey)
            } else {
                UserDefaults.standard.removeObject(forKey: tokenKey)
            }
        }
    }

    var hasToken: Bool { !(token ?? "").isEmpty }

    // MARK: - 核心请求

    @discardableResult
    func call<T: Decodable>(_ route: String,
                            method: String = "GET",
                            query: [String: String] = [:],
                            json: [String: Any]? = nil) async throws -> T {
        var components = URLComponents(url: base.appendingPathComponent("api.php"),
                                       resolvingAgainstBaseURL: false)!
        var queryItems = [URLQueryItem(name: "r", value: route)]
        for (key, value) in query {
            queryItems.append(URLQueryItem(name: key, value: value))
        }
        components.queryItems = queryItems
        guard let url = components.url else { throw APIError.network("请求地址无效") }

        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        if let token, !token.isEmpty {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        if let json {
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = try JSONSerialization.data(withJSONObject: json)
        }

        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await session.data(for: request)
        } catch {
            throw APIError.network("网络连接失败，请检查网络后重试")
        }

        // 服务端所有错误都是 {ok:false,error:"..."}，优先按业务错误处理
        if let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           let ok = object["ok"] as? Bool, ok == false {
            throw APIError.server((object["error"] as? String) ?? "请求失败")
        }

        if let http = response as? HTTPURLResponse, http.statusCode >= 400 {
            throw APIError.server("服务器错误（\(http.statusCode)）")
        }

        do {
            return try decoder.decode(T.self, from: data)
        } catch {
            throw APIError.decoding
        }
    }

    // MARK: - 接口

    func bootstrap() async throws -> BootstrapResponse {
        try await call("bootstrap")
    }

    func challenge() async throws -> ChallengeResponse {
        try await call("challenge")
    }

    func login(username: String, password: String, human: String, remember: Bool) async throws -> LoginResponse {
        try await call("login", method: "POST", json: [
            "username": username,
            "password": password,
            "human": human,
            "remember": remember ? "1" : "0",
            "device": "gayChou iOS 1.0"
        ])
    }

    func logout() async throws {
        let _: SimpleResponse = try await call("logout", method: "POST")
    }

    func sendCode(email: String, human: String) async throws {
        let _: SimpleResponse = try await call("sendcode", method: "POST", json: [
            "email": email,
            "human": human
        ])
    }

    func register(username: String, email: String, code: String, password: String, agree: Bool) async throws -> LoginResponse {
        try await call("register", method: "POST", json: [
            "username": username,
            "email": email,
            "code": code,
            "password": password,
            "agree": agree ? "1" : "0"
        ])
    }

    func me() async throws -> MeResponse {
        try await call("me")
    }

    func feed(tab: FeedTab, page: Int) async throws -> FeedResponse {
        try await call("feed", query: ["tab": tab.rawValue, "page": String(page)])
    }

    func script(id: Int) async throws -> ScriptDetailResponse {
        try await call("script", query: ["id": String(id)])
    }

    func thread(id: Int) async throws -> ThreadDetailResponse {
        try await call("thread", query: ["id": String(id)])
    }

    func resource(id: Int) async throws -> ResourceDetailResponse {
        try await call("resource", query: ["id": String(id)])
    }

    func search(keyword: String) async throws -> SearchResponse {
        try await call("search", query: ["q": keyword])
    }

    func like(id: Int) async throws -> LikeResponse {
        try await call("like", method: "POST", json: ["id": id])
    }

    func comment(scriptID: Int, content: String, parentID: Int = 0) async throws {
        let _: SimpleResponse = try await call("comment", method: "POST", json: [
            "id": scriptID,
            "content": content,
            "parent_id": parentID
        ])
    }

    func reply(threadID: Int, content: String) async throws {
        let _: SimpleResponse = try await call("reply", method: "POST", json: [
            "id": threadID,
            "content": content
        ])
    }

    @discardableResult
    func newThread(title: String, content: String, tag: String) async throws -> CreatedResponse {
        try await call("newthread", method: "POST", json: [
            "title": title,
            "content": content,
            "tag": tag
        ])
    }
}
