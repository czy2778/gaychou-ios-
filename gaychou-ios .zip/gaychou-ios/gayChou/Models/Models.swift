import Foundation

// MARK: - 站点

struct SiteInfo: Decodable {
    let name: String?
    let base: String?
    let logo: String?
}

// MARK: - 用户

struct User: Decodable, Identifiable, Equatable {
    let id: Int
    let name: String
    let email: String?
    let role: String?
    let avatar: String?
    let banned: Bool?

    var isOwner: Bool { (role ?? "") == "owner" || (role ?? "") == "admin" }
    var avatarURL: URL? { URL(string: avatar ?? "") }
}

struct Author: Decodable, Identifiable {
    let id: Int
    let name: String
}

// MARK: - 内容条目（三端共用同一结构）

struct FeedItem: Decodable, Identifiable {
    let type: String
    let id: Int
    let title: String
    let excerpt: String?
    let author: Author?
    let avatar: String?
    let ago: String?
    let createdAt: String?
    let likes: Int?
    let comments: Int?
    let views: Int?
    let pinned: Bool?
    let image: String?
    let tag: String?
    let solved: Bool?

    var avatarURL: URL? { URL(string: avatar ?? "") }
    var imageURL: URL? {
        guard let image, !image.isEmpty else { return nil }
        return URL(string: image)
    }
    var route: FeedRoute {
        switch type {
        case "thread": return .thread(id)
        case "resource": return .resource(id)
        default: return .script(id)
        }
    }
    var typeLabel: String {
        switch type {
        case "thread": return "提问"
        case "resource": return "资源"
        default: return "脚本"
        }
    }
}

enum FeedRoute: Hashable {
    case script(Int)
    case thread(Int)
    case resource(Int)
}

// MARK: - 详情

struct CommentItem: Decodable, Identifiable {
    let id: Int
    let name: String?
    let avatar: String?
    let content: String?
    let ago: String?

    var avatarURL: URL? { URL(string: avatar ?? "") }
}

struct ForumPost: Decodable, Identifiable {
    let id: Int
    let name: String?
    let avatar: String?
    let content: String?
    let ago: String?
    let accepted: Bool?

    var avatarURL: URL? { URL(string: avatar ?? "") }
}

struct ResourceFile: Decodable, Identifiable {
    let id: Int
    let name: String?
    let size: Int?
    let sizeText: String?
    let downloads: Int?
    let url: String?

    var fileURL: URL? { URL(string: url ?? "") }
}

// MARK: - 响应封装

struct BootstrapResponse: Decodable {
    let ok: Bool
    let site: SiteInfo?
    let user: User?
    let tags: [String: String]?
    let version: Int?
}

struct ChallengeResponse: Decodable {
    let ok: Bool
    let question: String?
}

struct LoginResponse: Decodable {
    let ok: Bool
    let token: String?
    let user: User?
}

struct SimpleResponse: Decodable {
    let ok: Bool
    let error: String?
}

struct FeedResponse: Decodable {
    let ok: Bool
    let tab: String?
    let page: Int?
    let more: Bool?
    let items: [FeedItem]?
}

struct ScriptDetailResponse: Decodable {
    let ok: Bool
    let item: FeedItem?
    let content: String?
    let locked: Bool?
    let description: String?
    let liked: Bool?
    let comments: [CommentItem]?
    let totalComments: Int?
}

struct ThreadDetailResponse: Decodable {
    let ok: Bool
    let item: FeedItem?
    let content: String?
    let tagName: String?
    let posts: [ForumPost]?
}

struct ResourceDetailResponse: Decodable {
    let ok: Bool
    let item: FeedItem?
    let description: String?
    let files: [ResourceFile]?
    let tags: [String]?
}

struct SearchResponse: Decodable {
    let ok: Bool
    let items: [FeedItem]?
    let q: String?
}

struct LikeResponse: Decodable {
    let ok: Bool
    let liked: Bool?
    let likes: Int?
}

struct MeCounts: Decodable {
    let scripts: Int?
    let threads: Int?
}

struct MeResponse: Decodable {
    let ok: Bool
    let user: User?
    let counts: MeCounts?
}

struct CreatedResponse: Decodable {
    let ok: Bool
    let id: Int?
}

// MARK: - 首页分区

enum FeedTab: String, CaseIterable, Identifiable {
    case script
    case ask
    case resource

    var id: String { rawValue }

    var title: String {
        switch self {
        case .script: return "脚本"
        case .ask: return "提问"
        case .resource: return "资源"
        }
    }

    var icon: String {
        switch self {
        case .script: return "chevron.left.forwardslash.chevron.right"
        case .ask: return "bubble.left.and.bubble.right"
        case .resource: return "shippingbox"
        }
    }
}
