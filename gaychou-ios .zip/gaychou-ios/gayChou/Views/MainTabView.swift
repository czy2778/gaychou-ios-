import SwiftUI

struct MainTabView: View {
    @State private var selection = 0

    var body: some View {
        ZStack(alignment: .bottom) {
            Group {
                switch selection {
                case 0:
                    NavigationHost { HomeView() }
                case 1:
                    NavigationHost { SearchView() }
                case 2:
                    NavigationHost { ComposeView() }
                default:
                    NavigationHost { MeView() }
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)

            GlassTabBar(selection: $selection)
        }
    }
}

/// 每个 tab 自带一个 NavigationStack，并按路由跳转详情
struct NavigationHost<Content: View>: View {
    let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        NavigationStack {
            content
                .navigationDestination(for: FeedRoute.self) { route in
                    DestinationView(route: route)
                }
        }
    }
}

struct DestinationView: View {
    let route: FeedRoute

    var body: some View {
        switch route {
        case .script(let id):
            ScriptDetailView(id: id)
        case .thread(let id):
            ThreadDetailView(id: id)
        case .resource(let id):
            ResourceDetailView(id: id)
        }
    }
}
