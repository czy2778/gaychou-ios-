import SwiftUI

struct LoginView: View {
    @EnvironmentObject private var session: Session

    @State private var username = ""
    @State private var password = ""
    @State private var answer = ""
    @State private var question = ""
    @State private var loading = false
    @State private var errorText: String?
    @State private var showRegister = false

    var body: some View {
        ScrollView {
            VStack(spacing: 26) {
                brand
                loginCard
                footer
            }
            .padding(.horizontal, 22)
            .padding(.top, 64)
            .padding(.bottom, 40)
        }
        .scrollIndicators(.hidden)
        .onAppear {
            if question.isEmpty {
                Task { await loadChallenge() }
            }
        }
        .sheet(isPresented: $showRegister) {
            RegisterView().environmentObject(session)
        }
    }

    // MARK: 品牌

    private var brand: some View {
        VStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 28, style: .continuous)
                    .fill(Theme.accentGradient)
                    .frame(width: 84, height: 84)
                    .shadow(color: Theme.accent.opacity(0.55), radius: 26, x: 0, y: 12)

                Image(systemName: "drop.fill")
                    .font(.system(size: 34, weight: .semibold))
                    .foregroundStyle(.white)
                    .rotationEffect(.degrees(180))
            }

            Text(session.site?.name ?? "gayChou")
                .font(.system(size: 28, weight: .bold, design: .rounded))
                .foregroundStyle(.white)

            Text("登录后与网页端数据实时同步")
                .font(.system(size: 12))
                .foregroundStyle(Theme.textTertiary)
        }
    }

    // MARK: 登录卡片

    private var loginCard: some View {
        VStack(spacing: 14) {
            field(icon: "person", placeholder: "用户名 / 邮箱", text: $username)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()

            secureField(icon: "lock", placeholder: "密码", text: $password)

            challengeRow

            if let errorText {
                HStack(spacing: 6) {
                    Image(systemName: "exclamationmark.circle.fill")
                    Text(errorText)
                }
                .font(.system(size: 12))
                .foregroundStyle(Color(hex: 0xFF6B6B))
                .frame(maxWidth: .infinity, alignment: .leading)
            }

            PrimaryButton(title: "登录", icon: "arrow.right", loading: loading, disabled: !canSubmit) {
                Task { await submit() }
            }
            .padding(.top, 2)
        }
        .glassCard(cornerRadius: 28, padding: 20)
    }

    private var challengeRow: some View {
        HStack(spacing: 10) {
            Image(systemName: "checkmark.shield")
                .foregroundStyle(Theme.textTertiary)

            Text(question.isEmpty ? "验证题加载中…" : question)
                .font(.system(size: 13, weight: .medium))
                .foregroundStyle(Theme.textSecondary)

            Spacer(minLength: 8)

            TextField("答案", text: $answer)
                .keyboardType(.numbersAndPunctuation)
                .multilineTextAlignment(.center)
                .foregroundStyle(.white)
                .frame(width: 74)
                .padding(.vertical, 9)
                .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 10, style: .continuous))

            Button {
                Task { await loadChallenge() }
            } label: {
                Image(systemName: "arrow.clockwise")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(Theme.accentCyan)
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 6)
        .background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    private var footer: some View {
        VStack(spacing: 12) {
            HStack(spacing: 4) {
                Text("还没有账号？")
                    .font(.system(size: 12))
                    .foregroundStyle(Theme.textTertiary)
                Button("注册") { showRegister = true }
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(Theme.accentCyan)
                    .buttonStyle(.plain)
            }

            Text("注册需要邮箱验证码；若站点未配置邮件服务，请到网页端注册")
                .font(.system(size: 10))
                .foregroundStyle(Theme.textTertiary.opacity(0.8))
                .multilineTextAlignment(.center)
        }
    }

    // MARK: 组件

    private func field(icon: String, placeholder: String, text: Binding<String>) -> some View {
        HStack(spacing: 10) {
            Image(systemName: icon).foregroundStyle(Theme.textTertiary).frame(width: 18)
            TextField(placeholder, text: text)
                .foregroundStyle(.white)
                .textFieldStyle(.plain)
        }
        .padding(14)
        .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .strokeBorder(Color.white.opacity(0.12), lineWidth: 1)
        )
    }

    private func secureField(icon: String, placeholder: String, text: Binding<String>) -> some View {
        HStack(spacing: 10) {
            Image(systemName: icon).foregroundStyle(Theme.textTertiary).frame(width: 18)
            SecureField(placeholder, text: text)
                .foregroundStyle(.white)
                .textFieldStyle(.plain)
        }
        .padding(14)
        .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .strokeBorder(Color.white.opacity(0.12), lineWidth: 1)
        )
    }

    // MARK: 逻辑

    private var canSubmit: Bool {
        !username.trimmingCharacters(in: .whitespaces).isEmpty &&
        !password.isEmpty &&
        !answer.trimmingCharacters(in: .whitespaces).isEmpty &&
        !loading
    }

    private func loadChallenge() async {
        do {
            let response = try await APIClient.shared.challenge()
            question = response.question ?? ""
            answer = ""
        } catch {
            question = ""
            errorText = (error as? LocalizedError)?.errorDescription
        }
    }

    private func submit() async {
        errorText = nil
        loading = true
        defer { loading = false }
        do {
            try await session.login(
                username: username.trimmingCharacters(in: .whitespaces),
                password: password,
                human: answer.trimmingCharacters(in: .whitespaces)
            )
        } catch {
            errorText = (error as? LocalizedError)?.errorDescription ?? "登录失败"
            // 验证题一次性有效：失败后必须换一道
            await loadChallenge()
        }
    }
}
