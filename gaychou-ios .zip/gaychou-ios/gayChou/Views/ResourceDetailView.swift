import SwiftUI

struct ResourceDetailView: View {
    let id: Int

    @State private var item: FeedItem?
    @State private var desc = ""
    @State private var files: [ResourceFile] = []
    @State private var tags: [String] = []
    @State private var loading = true
    @State private var errorText: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                if loading {
                    ProgressView().tint(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 80)
                } else if let errorText {
                    EmptyStateView(icon: "exclamationmark.triangle", title: errorText)
                } else {
                    header
                    if !desc.isEmpty { descCard }
                    filesCard
                    if !tags.isEmpty { tagsCard }
                }
            }
            .padding(.horizontal, 18)
            .padding(.top, 8)
            .padding(.bottom, 120)
        }
        .scrollIndicators(.hidden)
        .background(AuroraBackground())
        .navigationBarTitleDisplayMode(.inline)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .task { await load() }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 8) {
                if item?.pinned == true {
                    Chip(text: "官方", color: Theme.accentPink)
                }
                if let tag = item?.tag, !tag.isEmpty {
                    Chip(text: tag, color: Theme.accentCyan)
                }
                Spacer()
            }

            Text(item?.title ?? "")
                .font(.system(size: 22, weight: .bold))
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity, alignment: .leading)

            HStack(spacing: 10) {
                AvatarView(url: item?.avatarURL, size: 32)
                VStack(alignment: .leading, spacing: 2) {
                    Text(item?.author?.name ?? "已注销")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundStyle(Theme.textPrimary)
                    Text(item?.ago ?? "")
                        .font(.system(size: 11))
                        .foregroundStyle(Theme.textTertiary)
                }
                Spacer()
                MetricLabel(icon: "arrow.down.circle", value: "\(item?.views ?? 0)")
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard(cornerRadius: 24, padding: 16)
    }

    private var descCard: some View {
        Text(desc)
            .font(.system(size: 14))
            .foregroundStyle(Theme.textSecondary)
            .frame(maxWidth: .infinity, alignment: .leading)
            .textSelection(.enabled)
            .glassCard(cornerRadius: 24, padding: 16)
    }

    private var filesCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("文件")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(.white)
                Text("\(files.count)")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(Theme.textTertiary)
                Spacer()
            }

            if files.isEmpty {
                Text("暂无附件")
                    .font(.system(size: 13))
                    .foregroundStyle(Theme.textTertiary)
            } else {
                ForEach(files) { file in
                    if let url = file.fileURL {
                        Link(destination: url) {
                            fileRow(file)
                        }
                        .buttonStyle(.plain)
                    } else {
                        fileRow(file)
                    }
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard(cornerRadius: 24, padding: 16)
    }

    private func fileRow(_ file: ResourceFile) -> some View {
        HStack(spacing: 10) {
            Image(systemName: "doc.fill")
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(Theme.accentCyan)
                .frame(width: 30, height: 30)
                .background(Theme.accentCyan.opacity(0.14), in: RoundedRectangle(cornerRadius: 9, style: .continuous))

            VStack(alignment: .leading, spacing: 2) {
                Text(file.name ?? "文件")
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(Theme.textPrimary)
                    .lineLimit(1)
                Text("\(file.sizeText ?? "") · 下载 \(file.downloads ?? 0) 次")
                    .font(.system(size: 10))
                    .foregroundStyle(Theme.textTertiary)
            }

            Spacer()

            Image(systemName: "arrow.down.circle.fill")
                .font(.system(size: 18))
                .foregroundStyle(Theme.accentCyan)
        }
        .padding(10)
        .background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 13, style: .continuous))
    }

    private var tagsCard: some View {
        HStack(spacing: 8) {
            ForEach(tags, id: \.self) { tag in
                Chip(text: "#\(tag)", color: Theme.accentCyan)
            }
            Spacer()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard(cornerRadius: 20, padding: 14)
    }

    private func load() async {
        loading = true
        defer { loading = false }
        do {
            let response = try await APIClient.shared.resource(id: id)
            item = response.item
            desc = response.description ?? ""
            files = response.files ?? []
            tags = response.tags ?? []
            errorText = nil
        } catch {
            errorText = (error as? LocalizedError)?.errorDescription ?? "加载失败"
        }
    }
}
