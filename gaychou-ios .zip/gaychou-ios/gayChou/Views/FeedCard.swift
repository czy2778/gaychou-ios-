import SwiftUI

struct FeedCard: View {
    let item: FeedItem

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // 作者行
            HStack(spacing: 10) {
                AvatarView(url: item.avatarURL, size: 34)

                VStack(alignment: .leading, spacing: 2) {
                    Text(item.author?.name ?? "已注销")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(Theme.textPrimary)
                    Text(item.ago ?? "")
                        .font(.system(size: 11))
                        .foregroundStyle(Theme.textTertiary)
                }

                Spacer()

                if item.pinned == true {
                    Chip(text: "置顶", color: Theme.accentPink)
                }

                if let tag = item.tag, !tag.isEmpty {
                    Chip(text: tag, color: Theme.accentCyan)
                } else {
                    Chip(text: item.typeLabel, color: Theme.accentCyan)
                }
            }

            // 标题
            Text(item.title)
                .font(.system(size: 17, weight: .semibold))
                .foregroundStyle(Theme.textPrimary)
                .lineLimit(2)
                .multilineTextAlignment(.leading)
                .frame(maxWidth: .infinity, alignment: .leading)

            // 摘要
            if let excerpt = item.excerpt, !excerpt.isEmpty {
                Text(excerpt)
                    .font(.system(size: 13))
                    .foregroundStyle(Theme.textSecondary)
                    .lineLimit(3)
                    .multilineTextAlignment(.leading)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }

            // 封面
            if let imageURL = item.imageURL {
                AsyncImage(url: imageURL) { phase in
                    if let image = phase.image {
                        image.resizable().scaledToFill()
                    } else {
                        Rectangle().fill(Color.white.opacity(0.06))
                    }
                }
                .frame(height: 170)
                .frame(maxWidth: .infinity)
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            }

            // 指标
            HStack(spacing: 14) {
                MetricLabel(icon: "hand.thumbsup", value: "\(item.likes ?? 0)")
                MetricLabel(icon: "bubble.left", value: "\(item.comments ?? 0)")
                MetricLabel(icon: "eye", value: "\(item.views ?? 0)")

                Spacer()

                if item.solved == true {
                    Chip(text: "已解决", color: Color(hex: 0x4ADE80))
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard()
    }
}
