import SwiftUI
import UIKit

struct ScriptDetailView: View {
    let id: Int

    @State private var item: FeedItem?
    @State private var content = ""
    @State private var locked = false
    @State private var desc = ""
    @State private var liked = false
    @State private var likeCount = 0
    @State private var comments: [CommentItem] = []
    @State private var loading = true
    @State private var errorText: String?

    @State private var commentText = ""
    @State private var posting = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                if loading {
                    ProgressView().tint(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 80)
                } else if let errorText {
                    EmptyStateView(icon: "exclamationmark.triangle", title: errorText)
                } else {
                    header

                    if !desc.isEmpty {
                        Text(desc)
                            .font(.system(size: 14))
                            .foregroundStyle(Theme.textSecondary)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .glassCard(cornerRadius: 20, padding: 14)
                    }

                    sourceBlock

                    commentSection
                }
            }
            .padding(.horizontal, 18)
            .padding(.top, 8)
            .padding(.bottom, 120)
        }
        .scrollIndicators(.hidden)
        .background(AuroraBackground())
        .navigationBarTitleDisplayMode(.inline)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .task { await load() }
    }

    // MARK: 头部

    private var header: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(item?.title ?? "")
                .font(.system(size: 22, weight: .bold))
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity, alignment: .leading)

            HStack(spacing: 10) {
                AvatarView(url: item?.avatarURL, size: 32)
                VStack(alignment: .leading, spacing: 2) {
                    Text(item?.author?.name ?? "已注销")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundStyle(Theme.textPrimary)
                    Text(item?.ago ?? "")
                        .font(.system(size: 11))
                        .foregroundStyle(Theme.textTertiary)
                }
                Spacer()
                Button {
                    Task { await toggleLike() }
                } label: {
                    HStack(spacing: 5) {
                        Image(systemName: liked ? "hand.thumbsup.fill" : "hand.thumbsup")
                        Text("\(likeCount)")
                            .font(.system(size: 12, weight: .semibold))
                    }
                    .foregroundStyle(liked ? Theme.accentPink : Theme.textSecondary)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 7)
                    .glassPill()
                }
                .buttonStyle(.plain)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard(cornerRadius: 24, padding: 16)
    }

    // MARK: 源码

    private var sourceBlock: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Image(systemName: "chevron.left.forwardslash.chevron.right")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(Theme.accentCyan)
                Text("源码")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(Theme.textSecondary)
                Spacer()
                if !locked {
                    Button {
                        UIPasteboard.general.string = content
                    } label: {
                        Image(systemName: "doc.on.doc")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundStyle(Theme.accentCyan)
                    }
                    .buttonStyle(.plain)
                }
            }

            if locked {
                Text("该内容的源码未公开，仅作者可见。")
                    .font(.system(size: 13))
                    .foregroundStyle(Theme.textTertiary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.vertical, 20)
            } else {
                ScrollView(.horizontal, showsIndicators: false) {
                    Text(content.isEmpty ? "（空）" : content)
                        .font(.system(size: 12, design: .monospaced))
                        .foregroundStyle(Color(hex: 0xBFE9FF))
                        .textSelection(.enabled)
                        .padding(12)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .background(Color.black.opacity(0.35), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .strokeBorder(Color.white.opacity(0.1), lineWidth: 1)
                )
            }
        }
        .glassCard(cornerRadius: 24, padding: 16)
    }

    // MARK: 评论

    private var commentSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("评论")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(.white)
                Text("\(comments.count)")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(Theme.textTertiary)
                Spacer()
            }

            HStack(spacing: 10) {
                TextField("说点什么…", text: $commentText, axis: .vertical)
                    .lineLimit(1...4)
                    .foregroundStyle(.white)
                    .textFieldStyle(.plain)
                    .padding(12)
                    .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 13, style: .continuous))

                Button {
                    Task { await postComment() }
                } label: {
                    Image(systemName: "paperplane.fill")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(.white)
                        .padding(12)
                        .background(Theme.accentGradient, in: Circle())
                        .opacity(commentText.trimmingCharacters(in: .whitespaces).isEmpty || posting ? 0.45 : 1)
                }
                .buttonStyle(.plain)
                .disabled(commentText.trimmingCharacters(in: .whitespaces).isEmpty || posting)
            }

            ForEach(comments) { comment in
                HStack(alignment: .top, spacing: 10) {
                    AvatarView(url: comment.avatarURL, size: 30)
                    VStack(alignment: .leading, spacing: 4) {
                        HStack(spacing: 6) {
                            Text(comment.name ?? "已注销")
                                .font(.system(size: 12, weight: .semibold))
                                .foregroundStyle(Theme.textPrimary)
                            Text(comment.ago ?? "")
                                .font(.system(size: 10))
                                .foregroundStyle(Theme.textTertiary)
                        }
                        Text(comment.content ?? "")
                            .font(.system(size: 13))
                            .foregroundStyle(Theme.textSecondary)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
                .padding(12)
                .background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard(cornerRadius: 24, padding: 16)
    }

    // MARK: 数据

    private func load() async {
        loading = true
        defer { loading = false }
        do {
            let response = try await APIClient.shared.script(id: id)
            item = response.item
            content = response.content ?? ""
            locked = response.locked ?? false
            desc = response.description ?? ""
            liked = response.liked ?? false
            likeCount = response.item?.likes ?? 0
            comments = response.comments ?? []
            errorText = nil
        } catch {
            errorText = (error as? LocalizedError)?.errorDescription ?? "加载失败"
        }
    }

    private func toggleLike() async {
        guard let result = try? await APIClient.shared.like(id: id) else { return }
        liked = result.liked ?? liked
        likeCount = result.likes ?? likeCount
    }

    private func postComment() async {
        let text = commentText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        posting = true
        defer { posting = false }
        do {
            try await APIClient.shared.comment(scriptID: id, content: text)
            commentText = ""
            await load()
        } catch {
            errorText = (error as? LocalizedError)?.errorDescription
        }
    }
}
