import SwiftUI

struct RootView: View {
    @EnvironmentObject private var session: Session

    var body: some View {
        ZStack {
            AuroraBackground()

            if session.booting {
                SplashView()
            } else if session.isLoggedIn {
                MainTabView()
                    .transition(.opacity)
            } else {
                LoginView()
                    .transition(.opacity)
            }

            if let toast = session.toast {
                VStack {
                    Spacer()
                    ToastBanner(text: toast)
                        .padding(.bottom, 110)
                }
                .transition(.move(edge: .bottom).combined(with: .opacity))
                .allowsHitTesting(false)
            }
        }
        .animation(.easeInOut(duration: 0.25), value: session.isLoggedIn)
        .animation(.easeInOut(duration: 0.2), value: session.toast)
        .task {
            if session.booting {
                await session.boot()
            }
        }
    }
}

// MARK: - 启动页

struct SplashView: View {
    @State private var pulse = false

    var body: some View {
        VStack(spacing: 20) {
            ZStack {
                RoundedRectangle(cornerRadius: 30, style: .continuous)
                    .fill(Theme.accentGradient)
                    .frame(width: 96, height: 96)
                    .shadow(color: Theme.accent.opacity(0.6), radius: 30, x: 0, y: 12)
                    .scaleEffect(pulse ? 1.05 : 0.95)

                Image(systemName: "drop.fill")
                    .font(.system(size: 40, weight: .semibold))
                    .foregroundStyle(.white)
                    .rotationEffect(.degrees(180))
            }

            Text("gayChou")
                .font(.system(size: 26, weight: .bold, design: .rounded))
                .foregroundStyle(.white)

            Text("正在连接…")
                .font(.system(size: 13))
                .foregroundStyle(Theme.textTertiary)
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 1.2).repeatForever(autoreverses: true)) {
                pulse = true
            }
        }
    }
}

// MARK: - 轻提示

struct ToastBanner: View {
    let text: String

    var body: some View {
        Text(text)
            .font(.system(size: 13, weight: .medium))
            .foregroundStyle(.white)
            .padding(.horizontal, 18)
            .padding(.vertical, 11)
            .glassPill()
    }
}
