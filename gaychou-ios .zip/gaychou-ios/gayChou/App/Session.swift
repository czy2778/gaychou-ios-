import SwiftUI

@MainActor
final class Session: ObservableObject {
    @Published var user: User?
    @Published var site: SiteInfo?
    @Published var tags: [String: String] = [:]
    @Published var booting = true
    @Published var toast: String?

    var isLoggedIn: Bool { user != nil }

    // MARK: 启动

    func boot() async {
        if APIClient.shared.hasToken {
            do {
                let response = try await APIClient.shared.bootstrap()
                site = response.site
                tags = response.tags ?? [:]
                user = response.user
            } catch {
                // token 失效或无网络：回到登录页，不展示错误
                user = nil
            }
        } else {
            if let response = try? await APIClient.shared.bootstrap() {
                site = response.site
                tags = response.tags ?? [:]
            }
        }
        booting = false
    }

    // MARK: 登录 / 登出

    func login(username: String, password: String, human: String) async throws {
        let response = try await APIClient.shared.login(
            username: username,
            password: password,
            human: human,
            remember: true
        )
        guard let token = response.token, !token.isEmpty else {
            throw APIError.server("登录失败：服务器未返回凭证")
        }
        APIClient.shared.token = token
        user = response.user
        await refresh()
    }

    func refresh() async {
        guard let response = try? await APIClient.shared.bootstrap() else { return }
        site = response.site
        tags = response.tags ?? [:]
        if let latest = response.user {
            user = latest
        }
    }

    func logout() async {
        try? await APIClient.shared.logout()
        APIClient.shared.token = nil
        user = nil
        showToast("已退出登录")
    }

    // MARK: 轻提示

    func showToast(_ text: String) {
        toast = text
        Task { [weak self] in
            try? await Task.sleep(nanoseconds: 1_800_000_000)
            if self?.toast == text { self?.toast = nil }
        }
    }

    func tagName(_ key: String) -> String {
        tags[key] ?? key
    }
}
