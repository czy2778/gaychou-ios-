# gayChou iOS

`aly.gaychou.top` 的原生 iOS 客户端。与网页端**共用同一套后端、同一套账号与数据**，不新建数据库、不做任何数据分叉。

- 后端：`https://aly.gaychou.top/api.php`（站点自带的移动端 JSON API）
- 登录态：`Authorization: Bearer <token>`，与网页 session 等价
- 技术栈：SwiftUI + 原生材质（`.ultraThinMaterial`）玻璃效果，无任何第三方依赖

## 功能（与 API 对齐）

| 模块 | 能力 |
| --- | --- |
| 登录 / 注册 | 计算验证题、Bearer token、注册（邮箱验证码） |
| 首页 | 脚本 / 提问 / 资源 三个分区，分页加载、下拉刷新 |
| 详情 | 脚本（源码查看、复制、点赞、评论）、提问（正文、回复、采纳标记）、资源（文件列表、下载跳转、标签） |
| 搜索 | 全站搜索脚本 / 提问 / 资源 |
| 发布 | 发布提问帖（标题、正文、分类） |
| 我的 | 资料、发布统计、刷新、退出登录 |

> 管理后台、钱包、支付、邮件等**不在 App 内**——站点的 `api.php` 只暴露了用户侧接口，App 也只对接这些接口。

## 出未签名 IPA（推荐，无需 Mac）

1. 新建一个 GitHub 仓库，把本目录**全部文件**推上去（默认分支 `main` 或 `master`）
2. 打开仓库 **Actions** → 左侧 `Build unsigned IPA` → **Run workflow**
3. 等待约 3–5 分钟，在该次运行页面底部 **Artifacts** 下载 `gayChou-unsigned-ipa.zip`
4. 解压得到 `gayChou-unsigned.ipa`

工作流做的事：`brew install xcodegen` → `xcodegen generate` → `xcodebuild`（`CODE_SIGNING_ALLOWED=NO`）→ 打包 `Payload/gayChou.app` 成 `.ipa` → 上传 artifact。

## 安装到 iPhone

未签名 IPA 不能直接安装，需要侧载工具自动签名（用你自己的 Apple ID，免费）：

- **AltStore / SideStore**：装到手机后导入 IPA
- **Sideloadly**（Windows/Mac）：连数据线，拖入 IPA，填 Apple ID
- **TrollStore**（仅特定 iOS 版本）：可直接安装

免费 Apple ID 签名的应用 **7 天过期**，重签即可。

## 本地（Mac）构建

```bash
brew install xcodegen
xcodegen generate
open gayChou.xcodeproj
# Xcode 里选一台真机 / 模拟器运行
```

模拟器上也能跑（网络请求照常）。

## 登录

用站点账号登录即可（例如 `admin123`）。App 与网页登录状态互不影响，但数据实时一致。

## 目录结构

```
project.yml                     # XcodeGen 工程描述（CI 用它生成 .xcodeproj）
.github/workflows/build-ipa.yml # 构建未签名 IPA 的工作流
gayChou/
  App/          gayChouApp.swift, Session.swift
  Models/       Models.swift（与 api.php 返回结构一一对应）
  Networking/   APIClient.swift（16 个接口）
  Design/       Theme.swift, GlassComponents.swift（玻璃组件）
  Views/        Login / Home / FeedCard / 详情×3 / Search / Compose / Me
  Resources/    Assets.xcassets（AppIcon、AccentColor）
```

## 注意

- `api.php` 的注册验证码依赖站点邮件服务；若站点未配置 SMTP，注册会提示"站点邮件服务未配置"，请改用网页端注册。
- 站点使用 HTTPS，无需关闭 ATS。
- 若之后更换域名，改 `gayChou/Networking/APIClient.swift` 里的 `base` 一处即可。
