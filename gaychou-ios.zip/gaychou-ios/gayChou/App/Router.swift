import SwiftUI

struct SheetRoute: Identifiable {
    let id = UUID()
    let route: FeedRoute
}

struct WebTarget: Identifiable {
    let id = UUID()
    let path: String
    let title: String
}

/// 全局导航状态：侧边栏 / 详情小窗 / 网页全屏
@MainActor
final class Router: ObservableObject {
    @Published var showSidebar = false
    @Published var sheet: SheetRoute?
    @Published var web: WebTarget?
    @Published var tab = 0

    func open(_ route: FeedRoute) {
        showSidebar = false
        sheet = SheetRoute(route: route)
    }

    func openWeb(_ path: String, title: String) {
        showSidebar = false
        web = WebTarget(path: path, title: title)
    }

    func switchTab(_ index: Int) {
        showSidebar = false
        tab = index
    }
}
