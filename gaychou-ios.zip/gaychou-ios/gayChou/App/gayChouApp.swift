import SwiftUI

@main
struct GayChouApp: App {
    @StateObject private var session = Session()
    @StateObject private var router = Router()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(session)
                .environmentObject(router)
                .preferredColorScheme(.dark)
                .tint(Theme.accent)
        }
    }
}
