import SwiftUI

// MARK: - 背景

struct AuroraBackground: View {
    var body: some View {
        ZStack {
            Theme.backgroundGradient

            Circle()
                .fill(Theme.accent.opacity(0.55))
                .frame(width: 320, height: 320)
                .blur(radius: 90)
                .offset(x: -130, y: -240)

            Circle()
                .fill(Theme.accentCyan.opacity(0.38))
                .frame(width: 280, height: 280)
                .blur(radius: 95)
                .offset(x: 150, y: -120)

            Circle()
                .fill(Theme.accentPink.opacity(0.28))
                .frame(width: 300, height: 300)
                .blur(radius: 110)
                .offset(x: 90, y: 300)
        }
        .ignoresSafeArea()
    }
}

// MARK: - 头像

struct AvatarView: View {
    let url: URL?
    var size: CGFloat = 40

    var body: some View {
        Group {
            if let url = url {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image):
                        image.resizable().scaledToFill()
                    default:
                        placeholder
                    }
                }
            } else {
                placeholder
            }
        }
        .frame(width: size, height: size)
        .clipShape(Circle())
        .overlay(Circle().strokeBorder(Color.white.opacity(0.25), lineWidth: 1))
    }

    private var placeholder: some View {
        ZStack {
            Theme.accentGradient
            Image(systemName: "person.fill")
                .font(.system(size: size * 0.42, weight: .semibold))
                .foregroundStyle(.white.opacity(0.9))
        }
    }
}

// MARK: - 小标签

struct Chip: View {
    let text: String
    var color: Color = Theme.accentCyan

    var body: some View {
        Text(text)
            .font(.system(size: 11, weight: .semibold))
            .foregroundStyle(color)
            .padding(.horizontal, 9)
            .padding(.vertical, 4)
            .background(color.opacity(0.16), in: Capsule())
            .overlay(Capsule().strokeBorder(color.opacity(0.32), lineWidth: 0.8))
    }
}

// MARK: - 主按钮

struct PrimaryButton: View {
    let title: String
    var icon: String?
    var loading: Bool = false
    var disabled: Bool = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 8) {
                if loading {
                    ProgressView().tint(.white)
                } else if let icon = icon {
                    Image(systemName: icon).font(.system(size: 15, weight: .bold))
                }
                Text(title).font(.system(size: 16, weight: .semibold))
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 15)
            .foregroundStyle(.white)
            .background(Theme.accentGradient, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .strokeBorder(Color.white.opacity(0.25), lineWidth: 1)
            )
            .shadow(color: Theme.accent.opacity(0.45), radius: 18, x: 0, y: 8)
            .opacity(disabled || loading ? 0.55 : 1)
        }
        .disabled(disabled || loading)
        .buttonStyle(.plain)
    }
}

// MARK: - 指标

struct MetricLabel: View {
    let icon: String
    let value: String

    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: icon).font(.system(size: 11, weight: .semibold))
            Text(value).font(.system(size: 12, weight: .medium))
        }
        .foregroundStyle(Theme.textTertiary)
    }
}

// MARK: - 空状态

struct EmptyStateView: View {
    let icon: String
    let title: String
    var subtitle: String? = nil

    var body: some View {
        VStack(spacing: 12) {
            ZStack {
                Circle().fill(.ultraThinMaterial).frame(width: 76, height: 76)
                Image(systemName: icon)
                    .font(.system(size: 30, weight: .light))
                    .foregroundStyle(Theme.textSecondary)
            }
            Text(title)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(Theme.textSecondary)
            if let subtitle = subtitle {
                Text(subtitle)
                    .font(.system(size: 12))
                    .foregroundStyle(Theme.textTertiary)
                    .multilineTextAlignment(.center)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 60)
    }
}

// MARK: - 底部玻璃标签栏

struct GlassTabBar: View {
    @Binding var selection: Int

    private let items: [(icon: String, title: String)] = [
        ("house.fill", "首页"),
        ("magnifyingglass", "搜索"),
        ("plus.circle.fill", "发布"),
        ("person.fill", "我的")
    ]

    var body: some View {
        HStack(spacing: 2) {
            ForEach(items.indices, id: \.self) { index in
                let item = items[index]
                Button {
                    withAnimation(.spring(response: 0.34, dampingFraction: 0.82)) {
                        selection = index
                    }
                } label: {
                    VStack(spacing: 4) {
                        Image(systemName: item.icon)
                            .font(.system(size: 18, weight: .semibold))
                        Text(item.title)
                            .font(.system(size: 10, weight: .medium))
                    }
                    .foregroundStyle(selection == index ? Color.white : Theme.textTertiary)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
                    .background {
                        if selection == index {
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .fill(Theme.accent.opacity(0.28))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                                        .strokeBorder(Color.white.opacity(0.18), lineWidth: 1)
                                )
                        }
                    }
                }
                .buttonStyle(.plain)
            }
        }
        .padding(6)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .strokeBorder(
                    LinearGradient(colors: [Color.white.opacity(0.35), Color.white.opacity(0.05)],
                                   startPoint: .topLeading, endPoint: .bottomTrailing),
                    lineWidth: 1
                )
        )
        .shadow(color: Color.black.opacity(0.45), radius: 24, x: 0, y: 14)
        .padding(.horizontal, 18)
        .padding(.bottom, 6)
    }
}
