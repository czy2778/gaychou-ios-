import SwiftUI

// MARK: - 背景

struct AuroraBackground: View {
    var body: some View {
        ZStack {
            Theme.backgroundGradient

            Circle()
                .fill(Theme.accent.opacity(0.55))
                .frame(width: 320, height: 320)
                .blur(radius: 90)
                .offset(x: -130, y: -240)

            Circle()
                .fill(Theme.accentCyan.opacity(0.38))
                .frame(width: 280, height: 280)
                .blur(radius: 95)
                .offset(x: 150, y: -120)

            Circle()
                .fill(Theme.accentPink.opacity(0.28))
                .frame(width: 300, height: 300)
                .blur(radius: 110)
                .offset(x: 90, y: 300)
        }
        .ignoresSafeArea()
    }
}

// MARK: - 头像

struct AvatarView: View {
    let url: URL?
    var size: CGFloat = 40

    var body: some View {
        Group {
            if let url = url {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image):
                        image.resizable().scaledToFill()
                    default:
                        placeholder
                    }
                }
            } else {
                placeholder
            }
        }
        .frame(width: size, height: size)
        .clipShape(Circle())
        .overlay(Circle().strokeBorder(Color.white.opacity(0.25), lineWidth: 1))
    }

    private var placeholder: some View {
        ZStack {
            Theme.accentGradient
            Image(systemName: "person.fill")
                .font(.system(size: size * 0.42, weight: .semibold))
                .foregroundStyle(.white.opacity(0.9))
        }
    }
}

// MARK: - 小标签

struct Chip: View {
    let text: String
    var color: Color = Theme.accentCyan

    var body: some View {
        Text(text)
            .font(.system(size: 11, weight: .semibold))
            .foregroundStyle(color)
            .padding(.horizontal, 9)
            .padding(.vertical, 4)
            .background(color.opacity(0.16), in: Capsule())
            .overlay(Capsule().strokeBorder(color.opacity(0.32), lineWidth: 0.8))
    }
}

// MARK: - 主按钮

struct PrimaryButton: View {
    let title: String
    var icon: String? = nil
    var loading: Bool = false
    var disabled: Bool = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 8) {
                if loading {
                    ProgressView().tint(.white)
                } else if let icon = icon {
                    Image(systemName: icon).font(.system(size: 15, weight: .bold))
                }
                Text(title).font(.system(size: 16, weight: .semibold))
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 15)
            .foregroundStyle(.white)
            .background(Theme.accentGradient, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .strokeBorder(Color.white.opacity(0.25), lineWidth: 1)
            )
            .shadow(color: Theme.accent.opacity(0.45), radius: 18, x: 0, y: 8)
            .opacity(disabled || loading ? 0.55 : 1)
        }
        .disabled(disabled || loading)
        .buttonStyle(.plain)
    }
}

// MARK: - 指标

struct MetricLabel: View {
    let icon: String
    let value: String

    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: icon).font(.system(size: 11, weight: .semibold))
            Text(value).font(.system(size: 12, weight: .medium))
        }
        .foregroundStyle(Theme.textTertiary)
    }
}

// MARK: - 空状态

struct EmptyStateView: View {
    let icon: String
    let title: String
    var subtitle: String? = nil

    var body: some View {
        VStack(spacing: 12) {
            ZStack {
                Circle().fill(.ultraThinMaterial).frame(width: 76, height: 76)
                Image(systemName: icon)
                    .font(.system(size: 30, weight: .light))
                    .foregroundStyle(Theme.textSecondary)
            }
            Text(title)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(Theme.textSecondary)
                .multilineTextAlignment(.center)
            if let subtitle = subtitle {
                Text(subtitle)
                    .font(.system(size: 12))
                    .foregroundStyle(Theme.textTertiary)
                    .multilineTextAlignment(.center)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 60)
    }
}

// MARK: - 底部标签栏（iOS 26 Liquid Glass）

struct GlassTabBar: View {
    @Binding var selection: Int

    private let items: [(icon: String, title: String)] = [
        ("house.fill", "主页"),
        ("magnifyingglass", "搜索"),
        ("bubble.left.and.bubble.right.fill", "聊天"),
        ("person.fill", "我的")
    ]

    var body: some View {
        HStack(spacing: 2) {
            ForEach(items.indices, id: \.self) { index in
                let item = items[index]
                Button {
                    withAnimation(.spring(response: 0.34, dampingFraction: 0.82)) {
                        selection = index
                    }
                } label: {
                    VStack(spacing: 4) {
                        Image(systemName: item.icon)
                            .font(.system(size: 18, weight: .semibold))
                        Text(item.title)
                            .font(.system(size: 10, weight: .medium))
                    }
                    .foregroundStyle(selection == index ? Color.white : Theme.textTertiary)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 9)
                    .background {
                        if selection == index {
                            Capsule()
                                .fill(Theme.accent.opacity(0.30))
                                .overlay(Capsule().strokeBorder(Color.white.opacity(0.16), lineWidth: 1))
                        }
                    }
                }
                .buttonStyle(.plain)
            }
        }
        .padding(6)
        .liquidGlass(in: RoundedRectangle(cornerRadius: 28, style: .continuous), interactive: true)
        .shadow(color: Color.black.opacity(0.35), radius: 20, x: 0, y: 12)
        .padding(.horizontal, 18)
        .padding(.bottom, 6)
    }
}

// MARK: - 侧边导航

struct SideEntry: Identifiable {
    let id = UUID()
    let icon: String
    let title: String
    var tab: Int? = nil
    var path: String? = nil
}

struct SidebarView: View {
    @EnvironmentObject private var router: Router
    @EnvironmentObject private var session: Session

    private var sections: [(String, [SideEntry])] {
        [
            ("社区", [
                SideEntry(icon: "house", title: "主页", tab: 0),
                SideEntry(icon: "magnifyingglass", title: "搜索", tab: 1),
                SideEntry(icon: "bubble.left.and.bubble.right", title: "提问论坛", path: "forum.php"),
                SideEntry(icon: "shippingbox", title: "资源分享", path: "resources.php"),
                SideEntry(icon: "info.circle", title: "脚本信息", path: "info.php")
            ]),
            ("互动", [
                SideEntry(icon: "bell", title: "通知中心", path: "notifications.php"),
                SideEntry(icon: "message", title: "聊天", path: "chat.php")
            ]),
            ("我的", [
                SideEntry(icon: "key", title: "已购买脚本", path: "mypaid.php"),
                SideEntry(icon: "list.bullet.rectangle", title: "订单管理", path: "orders.php"),
                SideEntry(icon: "storefront", title: "商户管理", path: "paid_manage.php"),
                SideEntry(icon: "checkmark.seal", title: "iOS 签名", path: "ios_sign.php")
            ]),
            ("工具", [
                SideEntry(icon: "wand.and.stars", title: "AI 工具", path: "ai_tools.php"),
                SideEntry(icon: "shield.lefthalf.filled", title: "VMP 混淆", path: "vmp.php")
            ]),
            ("系统", [
                SideEntry(icon: "gearshape", title: "设置", path: "settings.php"),
                SideEntry(icon: "slider.horizontal.3", title: "管理后台", path: "admin.php")
            ])
        ]
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            header

            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    ForEach(sections.indices, id: \.self) { index in
                        let section = sections[index]
                        VStack(alignment: .leading, spacing: 8) {
                            Text(section.0)
                                .font(.system(size: 11, weight: .semibold))
                                .foregroundStyle(Theme.textTertiary)
                                .padding(.leading, 12)

                            ForEach(section.1) { entry in
                                row(entry)
                            }
                        }
                    }
                }
                .padding(.horizontal, 12)
                .padding(.top, 8)
                .padding(.bottom, 30)
            }
            .scrollIndicators(.hidden)
        }
        .frame(width: 306)
        .frame(maxHeight: .infinity, alignment: .top)
        .background(.ultraThinMaterial)
        .overlay(alignment: .trailing) {
            Rectangle()
                .fill(Color.white.opacity(0.12))
                .frame(width: 1)
        }
        .ignoresSafeArea()
    }

    private var header: some View {
        HStack(spacing: 12) {
            AvatarView(url: session.user?.avatarURL, size: 46)

            VStack(alignment: .leading, spacing: 3) {
                Text(session.user?.name ?? "未登录")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundStyle(.white)
                Text(session.user?.email ?? "")
                    .font(.system(size: 11))
                    .foregroundStyle(Theme.textTertiary)
                    .lineLimit(1)
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 18)
        .padding(.top, 62)
        .padding(.bottom, 16)
        .overlay(alignment: .bottom) {
            Rectangle().fill(Color.white.opacity(0.10)).frame(height: 1)
        }
    }

    private func row(_ entry: SideEntry) -> some View {
        Button {
            if let tab = entry.tab {
                router.switchTab(tab)
            } else if let path = entry.path {
                router.openWeb(path, title: entry.title)
            }
        } label: {
            HStack(spacing: 12) {
                Image(systemName: entry.icon)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(Theme.accentCyan)
                    .frame(width: 22)

                Text(entry.title)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundStyle(Theme.textPrimary)

                Spacer()

                if entry.path != nil {
                    Image(systemName: "arrow.up.right")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundStyle(Theme.textTertiary)
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 11)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

struct SidebarOverlay: View {
    @EnvironmentObject private var router: Router

    var body: some View {
        ZStack(alignment: .leading) {
            if router.showSidebar {
                Color.black.opacity(0.45)
                    .ignoresSafeArea()
                    .onTapGesture {
                        withAnimation(.spring(response: 0.32, dampingFraction: 0.9)) {
                            router.showSidebar = false
                        }
                    }
                    .transition(.opacity)

                SidebarView()
                    .transition(.move(edge: .leading))
            }
        }
        .animation(.spring(response: 0.34, dampingFraction: 0.86), value: router.showSidebar)
    }
}
