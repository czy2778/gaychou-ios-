import SwiftUI
import UIKit

struct ScriptDetailView: View {
    let id: Int

    @EnvironmentObject private var session: Session

    @State private var item: FeedItem?
    @State private var execLink = ""
    @State private var desc = ""
    @State private var liked = false
    @State private var likeCount = 0
    @State private var comments: [CommentItem] = []
    @State private var loading = true
    @State private var errorText: String?

    @State private var commentText = ""
    @State private var posting = false

    private var postURL: URL? {
        URL(string: "https://aly.gaychou.top/post.php?id=\(id)")
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                if loading {
                    ProgressView().tint(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 80)
                } else if let errorText = errorText {
                    EmptyStateView(icon: "exclamationmark.triangle", title: errorText)
                } else {
                    header

                    if !desc.isEmpty {
                        Text(desc)
                            .font(.system(size: 14))
                            .foregroundStyle(Theme.textSecondary)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .glassCard(cornerRadius: 20, padding: 14)
                    }

                    execCard
                    commentSection
                }
            }
            .padding(.horizontal, 18)
            .padding(.top, 8)
            .padding(.bottom, 40)
        }
        .scrollIndicators(.hidden)
        .background(AuroraBackground())
        .navigationBarTitleDisplayMode(.inline)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .task { await load() }
    }

    // MARK: 头部

    private var header: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(item?.title ?? "")
                .font(.system(size: 22, weight: .bold))
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity, alignment: .leading)

            HStack(spacing: 10) {
                AvatarView(url: item?.avatarURL, size: 32)

                VStack(alignment: .leading, spacing: 2) {
                    Text(item?.author?.name ?? "已注销")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundStyle(Theme.textPrimary)
                    Text(item?.ago ?? "")
                        .font(.system(size: 11))
                        .foregroundStyle(Theme.textTertiary)
                }

                Spacer()

                Button {
                    Task { await toggleLike() }
                } label: {
                    HStack(spacing: 5) {
                        Image(systemName: liked ? "hand.thumbsup.fill" : "hand.thumbsup")
                        Text("\(likeCount)")
                            .font(.system(size: 12, weight: .semibold))
                    }
                    .foregroundStyle(liked ? Theme.accentPink : Theme.textSecondary)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 7)
                    .glassPill()
                }
                .buttonStyle(.plain)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard(cornerRadius: 24, padding: 16)
    }

    // MARK: 执行链接（不展示源码）

    private var execCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 6) {
                Image(systemName: "link")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(Theme.accentCyan)
                Text("执行链接")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(Theme.textSecondary)
                Spacer()
            }

            if execLink.isEmpty {
                Text("该脚本暂未生成执行链接")
                    .font(.system(size: 13))
                    .foregroundStyle(Theme.textTertiary)
            } else {
                Text(execLink)
                    .font(.system(size: 11, design: .monospaced))
                    .foregroundStyle(Color(hex: 0xBFE9FF))
                    .lineLimit(3)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(10)
                    .background(Color.black.opacity(0.30), in: RoundedRectangle(cornerRadius: 12, style: .continuous))

                HStack(spacing: 8) {
                    actionButton("复制链接", icon: "doc.on.doc") {
                        UIPasteboard.general.string = execLink
                        session.showToast("执行链接已复制")
                    }

                    actionButton("复制执行代码", icon: "chevron.left.forwardslash.chevron.right") {
                        UIPasteboard.general.string = "loadstring(game:HttpGet(\"\(execLink)\"))()"
                        session.showToast("执行代码已复制")
                    }

                    Spacer(minLength: 0)
                }

                if let postURL = postURL {
                    Link(destination: postURL) {
                        HStack(spacing: 4) {
                            Text("在网页中打开帖子")
                            Image(systemName: "arrow.up.right")
                        }
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(Theme.textTertiary)
                    }
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard(cornerRadius: 24, padding: 16)
    }

    private func actionButton(_ title: String, icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 5) {
                Image(systemName: icon).font(.system(size: 11, weight: .semibold))
                Text(title).font(.system(size: 12, weight: .semibold))
            }
            .foregroundStyle(.white)
            .padding(.horizontal, 12)
            .padding(.vertical, 9)
            .background(Theme.accent.opacity(0.35), in: Capsule())
            .overlay(Capsule().strokeBorder(Color.white.opacity(0.18), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    // MARK: 评论

    private var commentSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 6) {
                Text("评论")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(.white)
                Text("\(comments.count)")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(Theme.textTertiary)
                Spacer()
            }

            HStack(spacing: 10) {
                TextField("说点什么…", text: $commentText, axis: .vertical)
                    .lineLimit(1...4)
                    .foregroundStyle(.white)
                    .textFieldStyle(.plain)
                    .padding(12)
                    .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 13, style: .continuous))

                Button {
                    Task { await postComment() }
                } label: {
                    Image(systemName: "paperplane.fill")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(.white)
                        .padding(12)
                        .background(Theme.accentGradient, in: Circle())
                        .opacity(commentText.trimmingCharacters(in: .whitespaces).isEmpty || posting ? 0.45 : 1)
                }
                .buttonStyle(.plain)
                .disabled(commentText.trimmingCharacters(in: .whitespaces).isEmpty || posting)
            }

            ForEach(comments) { comment in
                HStack(alignment: .top, spacing: 10) {
                    AvatarView(url: comment.avatarURL, size: 30)

                    VStack(alignment: .leading, spacing: 4) {
                        HStack(spacing: 6) {
                            Text(comment.name ?? "已注销")
                                .font(.system(size: 12, weight: .semibold))
                                .foregroundStyle(Theme.textPrimary)
                            Text(comment.ago ?? "")
                                .font(.system(size: 10))
                                .foregroundStyle(Theme.textTertiary)
                        }
                        Text(comment.content ?? "")
                            .font(.system(size: 13))
                            .foregroundStyle(Theme.textSecondary)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
                .padding(12)
                .background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard(cornerRadius: 24, padding: 16)
    }

    // MARK: 数据

    private func load() async {
        loading = true
        defer { loading = false }
        do {
            let response = try await APIClient.shared.script(id: id)
            item = response.item
            execLink = response.exec ?? ""
            desc = response.description ?? ""
            liked = response.liked ?? false
            likeCount = response.item?.likes ?? 0
            comments = response.comments ?? []
            errorText = nil
        } catch let err {
            errorText = (err as? LocalizedError)?.errorDescription ?? "加载失败"
        }
    }

    private func toggleLike() async {
        guard let result = try? await APIClient.shared.like(id: id) else { return }
        liked = result.liked ?? liked
        likeCount = result.likes ?? likeCount
    }

    /// 只追加本地评论，不整页重载
    private func postComment() async {
        let text = commentText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        posting = true
        defer { posting = false }
        do {
            try await APIClient.shared.comment(scriptID: id, content: text)
            let me = session.user
            comments.append(CommentItem(
                id: -Int.random(in: 1...999_999),
                name: me?.name,
                avatar: me?.avatar,
                content: text,
                ago: "刚刚"
            ))
            commentText = ""
            session.showToast("评论已发布")
        } catch let err {
            session.showToast((err as? LocalizedError)?.errorDescription ?? "评论失败")
        }
    }
}
