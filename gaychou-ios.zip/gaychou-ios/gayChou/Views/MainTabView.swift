import SwiftUI

struct MainTabView: View {
    @EnvironmentObject private var router: Router

    var body: some View {
        ZStack(alignment: .bottom) {
            Group {
                switch router.tab {
                case 0:
                    HomeView()
                case 1:
                    SearchView()
                case 2:
                    ChatTabView()
                default:
                    MeView()
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)

            GlassTabBar(selection: Binding(
                get: { router.tab },
                set: { router.tab = $0 }
            ))
        }
        .overlay {
            SidebarOverlay()
        }
        .sheet(item: $router.sheet) { sheetRoute in
            DetailSheet(route: sheetRoute.route)
                .presentationDetents([.large])
                .presentationDragIndicator(.visible)
                .presentationCornerRadius(30)
                .presentationBackground(.clear)
        }
        .fullScreenCover(item: $router.web) { target in
            WebPageView(target: target)
        }
    }
}

// MARK: - 统一的页面头部（含侧边栏按钮）

struct ScreenHeader: View {
    let title: String
    var subtitle: String? = nil

    @EnvironmentObject private var router: Router

    var body: some View {
        HStack(spacing: 12) {
            Button {
                withAnimation(.spring(response: 0.32, dampingFraction: 0.9)) {
                    router.showSidebar = true
                }
            } label: {
                Image(systemName: "line.3.horizontal")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 38, height: 38)
                    .liquidGlass(in: Circle(), interactive: true)
            }
            .buttonStyle(.plain)

            VStack(alignment: .leading, spacing: 1) {
                Text(title)
                    .font(.system(size: 22, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                if let subtitle = subtitle {
                    Text(subtitle)
                        .font(.system(size: 11))
                        .foregroundStyle(Theme.textTertiary)
                }
            }

            Spacer()
        }
    }
}

// MARK: - 帖子详情小窗

struct DetailSheet: View {
    let route: FeedRoute

    @EnvironmentObject private var router: Router

    var body: some View {
        NavigationStack {
            DestinationView(route: route)
                .toolbar {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button {
                            router.sheet = nil
                        } label: {
                            Image(systemName: "xmark")
                                .font(.system(size: 13, weight: .bold))
                        }
                    }
                }
        }
    }
}

struct DestinationView: View {
    let route: FeedRoute

    var body: some View {
        switch route {
        case .script(let id):
            ScriptDetailView(id: id)
        case .thread(let id):
            ThreadDetailView(id: id)
        case .resource(let id):
            ResourceDetailView(id: id)
        }
    }
}

// MARK: - 聊天（网页版，登录态共享）

struct ChatTabView: View {
    private let url = URL(string: "https://aly.gaychou.top/chat.php")!

    var body: some View {
        ZStack {
            AuroraBackground()

            VStack(spacing: 10) {
                ScreenHeader(title: "聊天", subtitle: "· 与网页同步")
                    .padding(.horizontal, 18)
                    .padding(.top, 6)

                WebView(url: url)
                    .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                    .padding(.horizontal, 12)
                    .padding(.bottom, 96)
            }
        }
    }
}
