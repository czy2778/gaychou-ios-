import SwiftUI

struct ThreadDetailView: View {
    let id: Int

    @State private var item: FeedItem?
    @State private var content = ""
    @State private var tagName = ""
    @State private var posts: [ForumPost] = []
    @State private var loading = true
    @State private var errorText: String?

    @State private var replyText = ""
    @State private var posting = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                if loading {
                    ProgressView().tint(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 80)
                } else if let errorText = errorText {
                    EmptyStateView(icon: "exclamationmark.triangle", title: errorText)
                } else {
                    header
                    bodyCard
                    replySection
                }
            }
            .padding(.horizontal, 18)
            .padding(.top, 8)
            .padding(.bottom, 120)
        }
        .scrollIndicators(.hidden)
        .background(AuroraBackground())
        .navigationBarTitleDisplayMode(.inline)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .task { await load() }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 8) {
                if !tagName.isEmpty {
                    Chip(text: tagName, color: Theme.accentCyan)
                }
                if item?.solved == true {
                    Chip(text: "已解决", color: Color(hex: 0x4ADE80))
                }
                Spacer()
            }

            Text(item?.title ?? "")
                .font(.system(size: 22, weight: .bold))
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity, alignment: .leading)

            HStack(spacing: 10) {
                AvatarView(url: item?.avatarURL, size: 32)
                VStack(alignment: .leading, spacing: 2) {
                    Text(item?.author?.name ?? "已注销")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundStyle(Theme.textPrimary)
                    Text(item?.ago ?? "")
                        .font(.system(size: 11))
                        .foregroundStyle(Theme.textTertiary)
                }
                Spacer()
                MetricLabel(icon: "eye", value: "\(item?.views ?? 0)")
                MetricLabel(icon: "bubble.left", value: "\(item?.comments ?? 0)")
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard(cornerRadius: 24, padding: 16)
    }

    private var bodyCard: some View {
        Text(content)
            .font(.system(size: 14))
            .foregroundStyle(Theme.textSecondary)
            .frame(maxWidth: .infinity, alignment: .leading)
            .textSelection(.enabled)
            .glassCard(cornerRadius: 24, padding: 16)
    }

    private var replySection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("回复")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(.white)
                Text("\(posts.count)")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(Theme.textTertiary)
                Spacer()
            }

            HStack(spacing: 10) {
                TextField("写下你的回答…", text: $replyText, axis: .vertical)
                    .lineLimit(1...5)
                    .foregroundStyle(.white)
                    .textFieldStyle(.plain)
                    .padding(12)
                    .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 13, style: .continuous))

                Button {
                    Task { await postReply() }
                } label: {
                    Image(systemName: "paperplane.fill")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(.white)
                        .padding(12)
                        .background(Theme.accentGradient, in: Circle())
                        .opacity(replyText.trimmingCharacters(in: .whitespaces).isEmpty || posting ? 0.45 : 1)
                }
                .buttonStyle(.plain)
                .disabled(replyText.trimmingCharacters(in: .whitespaces).isEmpty || posting)
            }

            ForEach(posts) { post in
                VStack(alignment: .leading, spacing: 8) {
                    HStack(spacing: 8) {
                        AvatarView(url: post.avatarURL, size: 28)
                        Text(post.name ?? "已注销")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundStyle(Theme.textPrimary)
                        if post.accepted == true {
                            Chip(text: "已采纳", color: Color(hex: 0x4ADE80))
                        }
                        Spacer()
                        Text(post.ago ?? "")
                            .font(.system(size: 10))
                            .foregroundStyle(Theme.textTertiary)
                    }

                    Text(post.content ?? "")
                        .font(.system(size: 13))
                        .foregroundStyle(Theme.textSecondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .textSelection(.enabled)
                }
                .padding(12)
                .background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard(cornerRadius: 24, padding: 16)
    }

    private func load() async {
        loading = true
        defer { loading = false }
        do {
            let response = try await APIClient.shared.thread(id: id)
            item = response.item
            content = response.content ?? ""
            tagName = response.tagName ?? ""
            posts = response.posts ?? []
            errorText = nil
        } catch {
            errorText = (error as? LocalizedError)?.errorDescription ?? "加载失败"
        }
    }

    private func postReply() async {
        let text = replyText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        posting = true
        defer { posting = false }
        do {
            try await APIClient.shared.reply(threadID: id, content: text)
            replyText = ""
            await load()
        } catch {
            errorText = (error as? LocalizedError)?.errorDescription
        }
    }
}
