import SwiftUI

struct RegisterView: View {
    @EnvironmentObject private var session: Session
    @Environment(\.dismiss) private var dismiss

    @State private var username = ""
    @State private var email = ""
    @State private var code = ""
    @State private var password = ""
    @State private var agree = false

    @State private var question = ""
    @State private var human = ""
    @State private var sending = false
    @State private var registering = false
    @State private var sent = false
    @State private var errorText: String?

    var body: some View {
        ZStack {
            AuroraBackground()

            ScrollView {
                VStack(spacing: 18) {
                    HStack {
                        Text("注册")
                            .font(.system(size: 22, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                        Spacer()
                        Button {
                            dismiss()
                        } label: {
                            Image(systemName: "xmark")
                                .font(.system(size: 13, weight: .bold))
                                .foregroundStyle(Theme.textSecondary)
                                .padding(9)
                                .background(Color.white.opacity(0.08), in: Circle())
                        }
                        .buttonStyle(.plain)
                    }

                    VStack(spacing: 12) {
                        input("person", "用户名（2-20 位）", text: $username)
                        input("envelope", "邮箱", text: $email)

                        HStack(spacing: 10) {
                            input("key", "邮箱验证码", text: $code)

                            Button(sent ? "已发送" : (sending ? "发送中…" : "发送")) {
                                Task { await sendCode() }
                            }
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 14)
                            .padding(.vertical, 13)
                            .background(Theme.accent.opacity(0.55), in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                            .disabled(sending || sent)
                            .buttonStyle(.plain)
                        }

                        HStack(spacing: 8) {
                            Text(question.isEmpty ? "验证题加载中…" : question)
                                .font(.system(size: 12))
                                .foregroundStyle(Theme.textSecondary)
                            Spacer()
                            TextField("答案", text: $human)
                                .keyboardType(.numbersAndPunctuation)
                                .multilineTextAlignment(.center)
                                .foregroundStyle(.white)
                                .frame(width: 66)
                                .padding(.vertical, 8)
                                .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                        }

                        secureInput("lock", "密码（至少 6 位）", text: $password)

                        Toggle(isOn: $agree) {
                            Text("我已阅读并同意《用户条款与免责声明》")
                                .font(.system(size: 11))
                                .foregroundStyle(Theme.textSecondary)
                        }
                        .toggleStyle(SwitchToggleStyle(tint: Theme.accent))
                        .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    .glassCard(cornerRadius: 26, padding: 18)

                    if let errorText = errorText {
                        Text(errorText)
                            .font(.system(size: 12))
                            .foregroundStyle(Color(hex: 0xFF6B6B))
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }

                    PrimaryButton(title: "注册并登录", icon: "person.badge.plus", loading: registering, disabled: !canRegister) {
                        Task { await register() }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                .padding(.bottom, 30)
            }
            .scrollIndicators(.hidden)
        }
        .task {
            if question.isEmpty { await loadChallenge() }
        }
    }

    private var canRegister: Bool {
        !username.isEmpty && !email.isEmpty && !code.isEmpty && !password.isEmpty && agree && !registering
    }

    private func input(_ icon: String, _ placeholder: String, text: Binding<String>) -> some View {
        HStack(spacing: 10) {
            Image(systemName: icon).foregroundStyle(Theme.textTertiary).frame(width: 18)
            TextField(placeholder, text: text)
                .foregroundStyle(.white)
                .textFieldStyle(.plain)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
        }
        .padding(13)
        .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 13, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 13, style: .continuous)
                .strokeBorder(Color.white.opacity(0.12), lineWidth: 1)
        )
    }

    private func secureInput(_ icon: String, _ placeholder: String, text: Binding<String>) -> some View {
        HStack(spacing: 10) {
            Image(systemName: icon).foregroundStyle(Theme.textTertiary).frame(width: 18)
            SecureField(placeholder, text: text)
                .foregroundStyle(.white)
                .textFieldStyle(.plain)
        }
        .padding(13)
        .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 13, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 13, style: .continuous)
                .strokeBorder(Color.white.opacity(0.12), lineWidth: 1)
        )
    }

    private func loadChallenge() async {
        if let response = try? await APIClient.shared.challenge() {
            question = response.question ?? ""
            human = ""
        }
    }

    private func sendCode() async {
        errorText = nil
        sending = true
        defer { sending = false }
        do {
            try await APIClient.shared.sendCode(email: email.trimmingCharacters(in: .whitespaces),
                                               human: human.trimmingCharacters(in: .whitespaces))
            sent = true
            await loadChallenge()
        } catch {
            errorText = (error as? LocalizedError)?.errorDescription ?? "发送失败"
        }
    }

    private func register() async {
        errorText = nil
        registering = true
        defer { registering = false }
        do {
            let response = try await APIClient.shared.register(
                username: username.trimmingCharacters(in: .whitespaces),
                email: email.trimmingCharacters(in: .whitespaces),
                code: code.trimmingCharacters(in: .whitespaces),
                password: password,
                agree: agree
            )
            if let token = response.token, !token.isEmpty {
                APIClient.shared.token = token
            }
            session.user = response.user
            await session.refresh()
            dismiss()
        } catch {
            errorText = (error as? LocalizedError)?.errorDescription ?? "注册失败"
        }
    }
}
