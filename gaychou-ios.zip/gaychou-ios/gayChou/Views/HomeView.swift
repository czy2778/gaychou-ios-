import SwiftUI

@MainActor
final class FeedModel: ObservableObject {
    @Published var items: [FeedItem] = []
    @Published var loading = false
    @Published var more = false
    @Published var error: String?
    @Published var loaded = false

    private var page = 1

    func load(tab: FeedTab, refresh: Bool) async {
        if loading { return }
        loading = true
        defer { loading = false }

        let target = refresh ? 1 : page + 1
        do {
            let response = try await APIClient.shared.feed(tab: tab, page: target)
            let newItems = response.items ?? []
            if refresh {
                items = newItems
            } else {
                items.append(contentsOf: newItems)
            }
            page = target
            more = response.more ?? false
            error = nil
        } catch let err {
            error = (err as? LocalizedError)?.errorDescription ?? "加载失败，请稍后重试"
        }
        loaded = true
    }

    func reset() {
        items = []
        page = 1
        more = false
        loaded = false
        error = nil
    }
}

struct HomeView: View {
    @EnvironmentObject private var session: Session
    @EnvironmentObject private var router: Router
    @StateObject private var model = FeedModel()
    @State private var tab: FeedTab = .script

    var body: some View {
        ScrollView {
            LazyVStack(spacing: 14) {
                ScreenHeader(title: session.site?.name ?? "gayChou", subtitle: "· 发现")

                tabsBar

                ForEach(model.items) { item in
                    Button {
                        router.open(item.route)
                    } label: {
                        FeedCard(item: item)
                    }
                    .buttonStyle(.plain)
                    .onAppear {
                        if item.id == model.items.last?.id, model.more {
                            Task { await model.load(tab: tab, refresh: false) }
                        }
                    }
                }

                if model.loading && !model.items.isEmpty {
                    ProgressView()
                        .tint(.white)
                        .padding(.vertical, 18)
                }

                if model.loaded && model.items.isEmpty {
                    EmptyStateView(
                        icon: "tray",
                        title: model.error ?? "这里还没有内容",
                        subtitle: model.error == nil ? "下拉可以刷新" : "下拉重试"
                    )
                }
            }
            .padding(.horizontal, 18)
            .padding(.top, 8)
            .padding(.bottom, 120)
        }
        .scrollIndicators(.hidden)
        .refreshable {
            await model.load(tab: tab, refresh: true)
        }
        .task {
            if !model.loaded {
                await model.load(tab: tab, refresh: true)
            }
        }
        .onChange(of: tab) { _ in
            model.reset()
            Task { await model.load(tab: tab, refresh: true) }
        }
    }

    private var tabsBar: some View {
        HStack(spacing: 6) {
            ForEach(FeedTab.allCases) { item in
                Button {
                    withAnimation(.spring(response: 0.32, dampingFraction: 0.85)) {
                        tab = item
                    }
                } label: {
                    HStack(spacing: 5) {
                        Image(systemName: item.icon)
                            .font(.system(size: 11, weight: .semibold))
                        Text(item.title)
                            .font(.system(size: 13, weight: .semibold))
                    }
                    .foregroundStyle(tab == item ? .white : Theme.textTertiary)
                    .padding(.horizontal, 13)
                    .padding(.vertical, 9)
                    .background {
                        if tab == item {
                            Capsule()
                                .fill(Theme.accent.opacity(0.32))
                                .overlay(Capsule().strokeBorder(Color.white.opacity(0.18), lineWidth: 1))
                        }
                    }
                }
                .buttonStyle(.plain)
            }
            Spacer(minLength: 0)
        }
        .padding(5)
        .liquidGlass(in: Capsule())
    }
}
