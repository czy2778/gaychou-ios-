import SwiftUI

struct MeView: View {
    @EnvironmentObject private var session: Session
    @EnvironmentObject private var router: Router

    @State private var counts: MeCounts?
    @State private var loading = false
    @State private var showLogout = false

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                header
                profileCard
                statsCard
                moreCard
                settingsCard
                aboutCard
            }
            .padding(.horizontal, 18)
            .padding(.top, 6)
            .padding(.bottom, 130)
        }
        .scrollIndicators(.hidden)
        .background(AuroraBackground())
        .task { await loadCounts() }
        .refreshable { await loadCounts() }
        .confirmationDialog("确定要退出登录吗？", isPresented: $showLogout, titleVisibility: .visible) {
            Button("退出登录", role: .destructive) {
                Task { await session.logout() }
            }
            Button("取消", role: .cancel) {}
        }
    }

    private var header: some View {
        HStack(alignment: .firstTextBaseline) {
            Text("我的")
                .font(.system(size: 28, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
            Text("· 个人中心")
                .font(.system(size: 13, weight: .medium))
                .foregroundStyle(Theme.textTertiary)
            Spacer()
        }
    }

    private var profileCard: some View {
        HStack(spacing: 14) {
            AvatarView(url: session.user?.avatarURL, size: 62)

            VStack(alignment: .leading, spacing: 5) {
                HStack(spacing: 7) {
                    Text(session.user?.name ?? "")
                        .font(.system(size: 19, weight: .bold))
                        .foregroundStyle(.white)
                    if session.user?.isOwner == true {
                        Chip(text: "站长", color: Theme.accentPink)
                    }
                }

                Text(session.user?.email ?? "")
                    .font(.system(size: 12))
                    .foregroundStyle(Theme.textTertiary)
                    .lineLimit(1)
            }

            Spacer(minLength: 0)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard(cornerRadius: 26, padding: 18)
    }

    private var statsCard: some View {
        HStack(spacing: 0) {
            statItem(value: counts?.scripts ?? 0, title: "发布脚本", icon: "chevron.left.forwardslash.chevron.right")
            divider
            statItem(value: counts?.threads ?? 0, title: "发布提问", icon: "bubble.left.and.bubble.right")
            divider
            statItem(value: session.tags.count, title: "板块分类", icon: "square.grid.2x2")
        }
        .glassCard(cornerRadius: 24, padding: 18)
    }

    private var divider: some View {
        Rectangle()
            .fill(Color.white.opacity(0.1))
            .frame(width: 1, height: 34)
    }

    private func statItem(value: Int, title: String, icon: String) -> some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(Theme.accentCyan)
            Text("\(value)")
                .font(.system(size: 19, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
            Text(title)
                .font(.system(size: 10))
                .foregroundStyle(Theme.textTertiary)
        }
        .frame(maxWidth: .infinity)
    }


    private var moreCard: some View {
        VStack(spacing: 0) {
            linkRow(icon: "key", title: "已购买脚本", path: "mypaid.php")
            RowDivider()
            linkRow(icon: "list.bullet.rectangle", title: "订单管理", path: "orders.php")
            RowDivider()
            linkRow(icon: "bell", title: "通知中心", path: "notifications.php")
            RowDivider()
            linkRow(icon: "wand.and.stars", title: "AI 工具", path: "ai_tools.php")
            RowDivider()
            linkRow(icon: "gearshape", title: "设置", path: "settings.php")
        }
        .glassCard(cornerRadius: 24, padding: 6)
    }

    private func linkRow(icon: String, title: String, path: String) -> some View {
        Button {
            router.openWeb(path, title: title)
        } label: {
            HStack(spacing: 12) {
                Image(systemName: icon)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(Theme.accentCyan)
                    .frame(width: 26)

                Text(title)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundStyle(Theme.textPrimary)

                Spacer()

                Image(systemName: "chevron.right")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(Theme.textTertiary)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 14)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    private var settingsCard: some View {
        VStack(spacing: 0) {
            row(icon: "arrow.triangle.2.circlepath", title: "刷新数据") {
                Task { await loadCounts(); await session.refresh() }
            }

            RowDivider()

            row(icon: "rectangle.portrait.and.arrow.right", title: "退出登录", destructive: true) {
                showLogout = true
            }
        }
        .glassCard(cornerRadius: 24, padding: 6)
    }

    private func row(icon: String, title: String, destructive: Bool = false, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image(systemName: icon)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(destructive ? Color(hex: 0xFF6B6B) : Theme.accentCyan)
                    .frame(width: 26)

                Text(title)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundStyle(destructive ? Color(hex: 0xFF6B6B) : Theme.textPrimary)

                Spacer()

                if !destructive {
                    if loading { ProgressView().tint(.white) }
                    else {
                        Image(systemName: "chevron.right")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundStyle(Theme.textTertiary)
                    }
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 14)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    private var aboutCard: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(session.site?.name ?? "gayChou")
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(Theme.textSecondary)
            Text("iOS 客户端 v1.0.0 · 与网页端共用同一账号与数据")
                .font(.system(size: 11))
                .foregroundStyle(Theme.textTertiary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard(cornerRadius: 20, padding: 14)
    }

    private func loadCounts() async {
        loading = true
        defer { loading = false }
        if let response = try? await APIClient.shared.me() {
            counts = response.counts
            if let latest = response.user {
                session.user = latest
            }
        }
    }
}

struct RowDivider: View {
    var body: some View {
        Rectangle()
            .fill(Color.white.opacity(0.08))
            .frame(height: 1)
            .padding(.leading, 50)
    }
}
