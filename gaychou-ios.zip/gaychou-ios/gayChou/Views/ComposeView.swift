import SwiftUI

struct ComposeView: View {
    @EnvironmentObject private var session: Session

    @State private var title = ""
    @State private var content = ""
    @State private var tag = "other"
    @State private var publishing = false
    @State private var errorText: String?
    @FocusState private var focused: Field?

    private enum Field { case title, content }

    /// 站点标签（与网页端同一套 tag）
    private var tagKeys: [String] {
        let preferred = ["install", "script", "account", "pay", "bug", "other"]
        let known = preferred.filter { session.tags[$0] != nil }
        let extra = session.tags.keys.filter { !preferred.contains($0) }
        return known + extra
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                header

                VStack(alignment: .leading, spacing: 12) {
                    Text("分类")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(Theme.textSecondary)

                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            ForEach(tagKeys, id: \.self) { key in
                                Button {
                                    withAnimation(.easeOut(duration: 0.15)) { tag = key }
                                } label: {
                                    Text(session.tagName(key))
                                        .font(.system(size: 12, weight: .semibold))
                                        .foregroundStyle(tag == key ? .white : Theme.textTertiary)
                                        .padding(.horizontal, 13)
                                        .padding(.vertical, 8)
                                        .background {
                                            if tag == key {
                                                Capsule().fill(Theme.accent.opacity(0.42))
                                                    .overlay(Capsule().strokeBorder(Color.white.opacity(0.2), lineWidth: 1))
                                            } else {
                                                Capsule().fill(Color.white.opacity(0.06))
                                            }
                                        }
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .glassCard(cornerRadius: 22, padding: 14)

                VStack(alignment: .leading, spacing: 12) {
                    TextField("标题（至少 4 个字）", text: $title, axis: .vertical)
                        .lineLimit(1...3)
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(.white)
                        .textFieldStyle(.plain)
                        .focused($focused, equals: .title)
                        .padding(13)
                        .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 14, style: .continuous))

                    TextEditor(text: $content)
                        .frame(minHeight: 180)
                        .scrollContentBackground(.hidden)
                        .foregroundStyle(.white)
                        .focused($focused, equals: .content)
                        .padding(9)
                        .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                        .overlay(alignment: .topLeading) {
                            if content.isEmpty {
                                Text("详细描述你的问题（至少 6 个字）")
                                    .font(.system(size: 14))
                                    .foregroundStyle(Theme.textTertiary)
                                    .padding(.horizontal, 14)
                                    .padding(.top, 17)
                                    .allowsHitTesting(false)
                            }
                        }
                }
                .glassCard(cornerRadius: 24, padding: 16)

                if let errorText = errorText {
                    Text(errorText)
                        .font(.system(size: 12))
                        .foregroundStyle(Color(hex: 0xFF6B6B))
                }

                PrimaryButton(title: "发布提问", icon: "paperplane.fill", loading: publishing, disabled: !canPublish) {
                    Task { await publish() }
                }

                Text("发布后可在网页端或 App 内查看；脚本与资源的发布请使用网页端。")
                    .font(.system(size: 10))
                    .foregroundStyle(Theme.textTertiary)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding(.horizontal, 18)
            .padding(.top, 6)
            .padding(.bottom, 130)
        }
        .scrollIndicators(.hidden)
        .background(AuroraBackground())
    }

    private var header: some View {
        HStack(alignment: .firstTextBaseline) {
            Text("发布")
                .font(.system(size: 28, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
            Text("· 提问")
                .font(.system(size: 13, weight: .medium))
                .foregroundStyle(Theme.textTertiary)
            Spacer()
        }
    }

    private var canPublish: Bool {
        title.trimmingCharacters(in: .whitespacesAndNewlines).count >= 4 &&
        content.trimmingCharacters(in: .whitespacesAndNewlines).count >= 6 &&
        !publishing
    }

    private func publish() async {
        errorText = nil
        publishing = true
        focused = nil
        defer { publishing = false }
        do {
            try await APIClient.shared.newThread(
                title: title.trimmingCharacters(in: .whitespacesAndNewlines),
                content: content.trimmingCharacters(in: .whitespacesAndNewlines),
                tag: tag
            )
            title = ""
            content = ""
            session.showToast("发布成功")
        } catch {
            errorText = (error as? LocalizedError)?.errorDescription ?? "发布失败"
        }
    }
}
