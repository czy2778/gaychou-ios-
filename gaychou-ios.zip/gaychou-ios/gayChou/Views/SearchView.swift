import SwiftUI

struct SearchView: View {
    @EnvironmentObject private var session: Session
    @State private var keyword = ""
    @State private var results: [FeedItem] = []
    @State private var searching = false
    @State private var searched = false
    @State private var errorText: String?
    @FocusState private var focused: Bool

    var body: some View {
        ScrollView {
            LazyVStack(spacing: 14) {
                header
                searchField

                if searching {
                    ProgressView().tint(.white).padding(.vertical, 40)
                } else if let errorText = errorText {
                    EmptyStateView(icon: "exclamationmark.triangle", title: errorText)
                } else if searched && results.isEmpty {
                    EmptyStateView(icon: "magnifyingglass", title: "没有找到相关内容", subtitle: "换个关键词试试")
                } else {
                    ForEach(results) { item in
                        NavigationLink(value: item.route) {
                            FeedCard(item: item)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            .padding(.horizontal, 18)
            .padding(.top, 6)
            .padding(.bottom, 116)
        }
        .scrollIndicators(.hidden)
        .background(AuroraBackground())
    }

    private var header: some View {
        HStack(alignment: .firstTextBaseline) {
            Text("搜索")
                .font(.system(size: 28, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
            Text("· 全站")
                .font(.system(size: 13, weight: .medium))
                .foregroundStyle(Theme.textTertiary)
            Spacer()
        }
    }

    private var searchField: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass")
                .foregroundStyle(Theme.textTertiary)

            TextField("搜索脚本 / 提问 / 资源", text: $keyword)
                .foregroundStyle(.white)
                .textFieldStyle(.plain)
                .autocorrectionDisabled()
                .focused($focused)
                .submitLabel(.search)
                .onSubmit { Task { await search() } }

            if !keyword.isEmpty {
                Button {
                    keyword = ""
                    results = []
                    searched = false
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundStyle(Theme.textTertiary)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(14)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .strokeBorder(Color.white.opacity(0.16), lineWidth: 1)
        )
    }

    private func search() async {
        let text = keyword.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        focused = false
        searching = true
        defer { searching = false }
        do {
            let response = try await APIClient.shared.search(keyword: text)
            results = response.items ?? []
            errorText = nil
        } catch {
            results = []
            errorText = (error as? LocalizedError)?.errorDescription ?? "搜索失败"
        }
        searched = true
    }
}
