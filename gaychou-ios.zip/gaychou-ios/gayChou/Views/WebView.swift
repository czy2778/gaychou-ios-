import SwiftUI
import WebKit

/// 用 WKWebView 承载网站页面；进入前把 App 的登录 Cookie 同步过去，
/// 做到「网页端和 App 是同一个登录态」。
struct WebView: UIViewRepresentable {
    let url: URL
    var onLoading: ((Bool) -> Void)? = nil

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.allowsInlineMediaPlayback = true

        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = context.coordinator
        webView.allowsBackForwardNavigationGestures = true
        webView.isOpaque = false
        webView.backgroundColor = .clear
        webView.scrollView.backgroundColor = .clear

        let cookieStore = configuration.websiteDataStore.httpCookieStore
        let cookies = HTTPCookieStorage.shared.cookies ?? []

        if cookies.isEmpty {
            webView.load(URLRequest(url: url))
        } else {
            let group = DispatchGroup()
            for cookie in cookies {
                group.enter()
                cookieStore.setCookie(cookie) { group.leave() }
            }
            group.notify(queue: .main) {
                webView.load(URLRequest(url: url))
            }
        }

        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(onLoading: onLoading)
    }

    final class Coordinator: NSObject, WKNavigationDelegate {
        let onLoading: ((Bool) -> Void)?

        init(onLoading: ((Bool) -> Void)?) {
            self.onLoading = onLoading
        }

        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            onLoading?(true)
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            onLoading?(false)
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            onLoading?(false)
        }
    }
}

struct WebPageView: View {
    let target: WebTarget

    @Environment(\.dismiss) private var dismiss
    @State private var loading = true

    private var url: URL? {
        URL(string: "https://aly.gaychou.top/" + target.path)
    }

    var body: some View {
        NavigationStack {
            ZStack {
                AuroraBackground()

                if let url = url {
                    WebView(url: url) { flag in
                        loading = flag
                    }
                    .ignoresSafeArea(edges: .bottom)

                    if loading {
                        VStack {
                            ProgressView().tint(.white)
                            Spacer()
                        }
                        .padding(.top, 40)
                    }
                } else {
                    EmptyStateView(icon: "exclamationmark.triangle", title: "链接无效")
                }
            }
            .navigationTitle(target.title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 13, weight: .bold))
                    }
                }
            }
        }
    }
}
