import SwiftUI

@main
struct GaychouApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
    }
}

// MARK: - 根容器（自定义底部导航，和网页同一套玻璃观感）

enum AppTab: Int, CaseIterable {
    case home, search, me

    var icon: String {
        switch self {
        case .home: return "house.fill"
        case .search: return "magnifyingglass"
        case .me: return "person.fill"
        }
    }

    var title: String {
        switch self {
        case .home: return "首页"
        case .search: return "搜索"
        case .me: return "我的"
        }
    }
}

@MainActor
final class UINav: ObservableObject {
    static let shared = UINav()
    @Published var homeDepth = 0
    @Published var searchDepth = 0
}

struct RootView: View {
    @StateObject private var session = Session.shared
    @StateObject private var nav = UINav.shared
    @State private var tab: AppTab = .home
    @State private var showCompose = false
    @State private var showLogin = false

    /// 页面常驻，切换只做位移 + 淡入，避免列表状态丢失
    private var tabBinding: Binding<AppTab> {
        Binding(
            get: { tab },
            set: { new in
                withAnimation(.spring(response: 0.36, dampingFraction: 0.88)) { tab = new }
            }
        )
    }

    var body: some View {
        ZStack(alignment: .bottom) {
            GlassBackground()

            ZStack {
                page(.home) { HomeView(onNeedLogin: { showLogin = true }) }
                page(.search) { SearchView(onNeedLogin: { showLogin = true }) }
                page(.me) { ProfileView(onNeedLogin: { showLogin = true }) }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)

            if showBottomBar {
                BottomBar(selection: tabBinding, onCompose: { showCompose = true })
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .animation(.easeInOut(duration: 0.22), value: showBottomBar)
        .sheet(isPresented: $showCompose) {
            ComposeView().presentationDetents([.large])
        }
        .sheet(isPresented: $showLogin) {
            LoginView()
        }
        .task { await session.bootstrap() }
    }

    private var showBottomBar: Bool {
        switch tab {
        case .home: return nav.homeDepth == 0
        case .search: return nav.searchDepth == 0
        case .me: return true
        }
    }

    @ViewBuilder
    private func page<Content: View>(_ t: AppTab, @ViewBuilder content: () -> Content) -> some View {
        let active = tab == t
        content()
            .opacity(active ? 1 : 0)
            .offset(x: active ? 0 : (t.rawValue < tab.rawValue ? -26 : 26))
            .allowsHitTesting(active)
            .accessibilityHidden(!active)
    }
}

// MARK: - 底部导航

struct BottomBar: View {
    @Binding var selection: AppTab
    var onCompose: () -> Void

    var body: some View {
        HStack(spacing: 6) {
            barButton(.home)
            barButton(.search)

            Button(action: onCompose) {
                Image(systemName: "plus")
                    .font(.system(size: 21, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(width: 50, height: 50)
                    .background(
                        Circle().fill(
                            LinearGradient(colors: [Color.gcBlue, Color(hex: 0x6B5CF6)],
                                           startPoint: .topLeading, endPoint: .bottomTrailing)
                        )
                    )
                    .shadow(color: Color.gcBlue.opacity(0.42), radius: 12, y: 6)
            }
            .offset(y: -9)

            barButton(.me)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 7)
        .background(
            Capsule()
                .fill(.ultraThinMaterial)
                .overlay(Capsule().strokeBorder(Color.white.opacity(0.22), lineWidth: 0.8))
                .shadow(color: .black.opacity(0.14), radius: 18, y: 8)
        )
        .padding(.horizontal, 24)
        .padding(.bottom, 4)
    }

    private func barButton(_ t: AppTab) -> some View {
        Button {
            selection = t
        } label: {
            VStack(spacing: 3) {
                Image(systemName: t.icon)
                    .font(.system(size: 18, weight: selection == t ? .semibold : .regular))
                Text(t.title).font(.system(size: 10, weight: .medium))
            }
            .foregroundStyle(selection == t ? Color.gcBlue : Color.secondary)
            .frame(width: 58, height: 44)
            .background(
                RoundedRectangle(cornerRadius: 13, style: .continuous)
                    .fill(selection == t ? Color.gcBlue.opacity(0.12) : .clear)
            )
        }
        .buttonStyle(.plain)
    }
}
