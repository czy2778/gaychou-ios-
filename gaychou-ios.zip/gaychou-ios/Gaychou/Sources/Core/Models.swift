import Foundation

// MARK: - 用户

struct User: Codable, Identifiable, Equatable {
    let id: Int
    var name: String
    var email: String
    var role: String
    var avatar: String
    var banned: Bool

    var isAdmin: Bool { role == "admin" || role == "owner" }
}

// MARK: - 列表条目（三种 feed 共用）

struct Author: Codable, Hashable {
    let id: Int
    let name: String
}

struct FeedItem: Codable, Identifiable, Hashable {
    let type: String          // script / thread / resource
    let id: Int
    let title: String
    let excerpt: String
    let author: Author
    let avatar: String
    let ago: String
    let likes: Int
    let comments: Int
    let views: Int
    let pinned: Bool
    let image: String
    let tag: String
    let solved: Bool

    var kind: ItemKind { ItemKind(rawValue: type) ?? .script }

    enum ItemKind: String {
        case script, thread, resource
    }
}

// MARK: - 响应

struct SiteInfo: Codable {
    let name: String
    let base: String
    let logo: String
}

struct BootstrapResponse: Codable {
    let ok: Bool
    let site: SiteInfo
    let user: User?
    let tags: [String: String]
}

struct FeedResponse: Codable {
    let ok: Bool
    let tab: String
    let page: Int
    let more: Bool
    let items: [FeedItem]
}

struct ChallengeResponse: Codable {
    let ok: Bool
    let question: String
}

struct AuthResponse: Codable {
    let ok: Bool
    let token: String
    let user: User
}

struct MeResponse: Codable {
    let ok: Bool
    let user: User
    let counts: Counts
    struct Counts: Codable {
        let scripts: Int
        let threads: Int
    }
}

struct CommentItem: Codable, Identifiable {
    let id: Int
    let name: String
    let avatar: String
    let content: String
    let ago: String
}

struct ScriptDetailResponse: Codable {
    let ok: Bool
    let item: FeedItem
    let content: String
    let locked: Bool
    let description: String
    let liked: Bool
    let comments: [CommentItem]
    let totalComments: Int

    enum CodingKeys: String, CodingKey {
        case ok, item, content, locked, description, liked, comments
        case totalComments = "total_comments"
    }
}

struct ReplyItem: Codable, Identifiable {
    let id: Int
    let name: String
    let avatar: String
    let content: String
    let ago: String
    let accepted: Bool
}

struct ThreadDetailResponse: Codable {
    let ok: Bool
    let item: FeedItem
    let content: String
    let tagName: String
    let posts: [ReplyItem]

    enum CodingKeys: String, CodingKey {
        case ok, item, content, posts
        case tagName = "tag_name"
    }
}

struct ResourceFile: Codable, Identifiable {
    let id: Int
    let name: String
    let size: Int
    let sizeText: String
    let downloads: Int
    let url: String

    enum CodingKeys: String, CodingKey {
        case id, name, size, downloads, url
        case sizeText = "size_text"
    }
}

struct ResourceDetailResponse: Codable {
    let ok: Bool
    let item: FeedItem
    let description: String
    let files: [ResourceFile]
    let tags: [String]
}

struct SearchResponse: Codable {
    let ok: Bool
    let items: [FeedItem]
    let q: String
}

struct LikeResponse: Codable {
    let ok: Bool
    let liked: Bool
    let likes: Int
}

struct SimpleOK: Codable {
    let ok: Bool
}

struct APIErrorBody: Codable {
    let ok: Bool?
    let error: String?
    let login: Bool?
}
