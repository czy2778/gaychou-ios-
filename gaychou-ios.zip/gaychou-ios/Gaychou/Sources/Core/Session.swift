import Foundation
import Combine

@MainActor
final class Session: ObservableObject {
    static let shared = Session()

    @Published private(set) var user: User?
    @Published private(set) var siteName: String = "gayChou"
    @Published private(set) var tags: [String: String] = [
        "install": "安装求助",
        "script": "脚本问题",
        "account": "账号相关",
        "pay": "支付订单",
        "bug": "Bug 反馈",
        "other": "其他"
    ]
    @Published private(set) var ready = false

    private init() {
        user = TokenStore.loadUser()
    }

    var isLoggedIn: Bool { user != nil }

    /// 启动时刷新站点信息与登录态
    func bootstrap() async {
        do {
            let r = try await APIClient.shared.bootstrap()
            siteName = r.site.name
            if !r.tags.isEmpty { tags = r.tags }
            if let u = r.user {
                user = u
                TokenStore.save(user: u)
            }
        } catch {
            // 离线也能用已缓存的登录态
        }
        ready = true
    }

    func signIn(username: String, password: String, human: String) async throws {
        let r = try await APIClient.shared.login(username: username, password: password, human: human)
        TokenStore.token = r.token
        user = r.user
        TokenStore.save(user: r.user)
    }

    func signUp(username: String, email: String, code: String, password: String) async throws {
        let r = try await APIClient.shared.register(username: username, email: email, code: code, password: password)
        TokenStore.token = r.token
        user = r.user
        TokenStore.save(user: r.user)
    }

    func refreshMe() async {
        guard isLoggedIn else { return }
        do {
            let r = try await APIClient.shared.me()
            user = r.user
            TokenStore.save(user: r.user)
        } catch let e as APIError where e.isAuthIssue {
            signOutLocal()
        } catch {
        }
    }

    func signOut() {
        Task { try? await APIClient.shared.logout() }
        signOutLocal()
    }

    private func signOutLocal() {
        TokenStore.token = nil
        TokenStore.save(user: nil)
        user = nil
    }
}
