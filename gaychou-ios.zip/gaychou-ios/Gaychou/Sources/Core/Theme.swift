import SwiftUI
import UIKit

// MARK: - 设计令牌

enum GC {
    static let blue   = Color(hex: 0x3978FA)
    static let purple = Color(hex: 0x8B5CF6)
    static let pink   = Color(hex: 0xFF5C8A)
    static let mint   = Color(hex: 0x22C7B8)
    static let amber  = Color(hex: 0xFFA63D)
}

extension Color {
    init(hex: UInt32, alpha: Double = 1) {
        self.init(.sRGB,
                  red: Double((hex >> 16) & 0xFF) / 255,
                  green: Double((hex >> 8) & 0xFF) / 255,
                  blue: Double(hex & 0xFF) / 255,
                  opacity: alpha)
    }

    static let gcBlue = Color(hex: 0x3978FA)
    static let gcInk = Color(hex: 0x111827)
    static let gcSub = Color(hex: 0x6B7686)
    static let gcLine = Color(hex: 0xE3E8F2)
}

// MARK: - 背景（玻璃 + 光斑，和网页同一套观感）

struct GlassBackground: View {
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        ZStack {
            LinearGradient(
                colors: scheme == .dark
                    ? [Color(hex: 0x0B0F16), Color(hex: 0x121826)]
                    : [Color(hex: 0xF7F9FE), Color(hex: 0xEDF2FB)],
                startPoint: .top, endPoint: .bottom
            )
            .ignoresSafeArea()

            GeometryReader { geo in
                let w = geo.size.width
                ZStack {
                    Circle()
                        .fill(Color.gcBlue.opacity(scheme == .dark ? 0.42 : 0.34))
                        .frame(width: w * 0.9)
                        .blur(radius: 90)
                        .offset(x: -w * 0.22, y: -geo.size.height * 0.28)
                    Circle()
                        .fill(Color(hex: 0x8B5CF6).opacity(scheme == .dark ? 0.30 : 0.22))
                        .frame(width: w * 0.75)
                        .blur(radius: 100)
                        .offset(x: w * 0.32, y: -geo.size.height * 0.06)
                    Circle()
                        .fill(Color(hex: 0x22C7B8).opacity(scheme == .dark ? 0.22 : 0.18))
                        .frame(width: w * 0.7)
                        .blur(radius: 110)
                        .offset(x: -w * 0.18, y: geo.size.height * 0.42)
                }
            }
            .ignoresSafeArea()
            .allowsHitTesting(false)
        }
    }
}

// MARK: - 玻璃卡片

struct GlassCard: ViewModifier {
    var radius: CGFloat = 20
    var padding: CGFloat = 16

    func body(content: Content) -> some View {
        content
            .padding(padding)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: radius, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: radius, style: .continuous)
                    .strokeBorder(Color.white.opacity(0.18), lineWidth: 0.8)
            )
            .shadow(color: Color.black.opacity(0.07), radius: 14, x: 0, y: 8)
    }
}

extension View {
    func glassCard(radius: CGFloat = 20, padding: CGFloat = 16) -> some View {
        modifier(GlassCard(radius: radius, padding: padding))
    }

    func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}

// MARK: - 小型通用控件

/// 胶囊标签
struct Pill: View {
    let text: String
    var color: Color = .gcBlue
    var filled: Bool = false

    var body: some View {
        Text(text)
            .font(.system(size: 11, weight: .semibold))
            .padding(.horizontal, 8)
            .padding(.vertical, 3)
            .foregroundStyle(filled ? .white : color)
            .background(
                Capsule().fill(filled ? color : color.opacity(0.12))
            )
    }
}

/// 数字 + 说明的统计格
struct StatCell: View {
    let value: String
    let label: String

    var body: some View {
        VStack(spacing: 3) {
            Text(value)
                .font(.system(size: 16, weight: .bold, design: .rounded))
                .foregroundStyle(.primary)
            Text(label)
                .font(.system(size: 11))
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
    }
}

/// 圆形头像（失败时显示首字）
struct AvatarView: View {
    let url: String
    let name: String
    var size: CGFloat = 40

    var body: some View {
        Group {
            if let u = URL(string: url), !url.contains("avatar_default") {
                AsyncImage(url: u) { phase in
                    if let img = phase.image {
                        img.resizable().scaledToFill()
                    } else {
                        fallback
                    }
                }
            } else {
                fallback
            }
        }
        .frame(width: size, height: size)
        .clipShape(Circle())
        .overlay(Circle().strokeBorder(Color.white.opacity(0.35), lineWidth: 0.8))
    }

    private var fallback: some View {
        ZStack {
            LinearGradient(colors: [Color.gcBlue.opacity(0.85), Color(hex: 0x8B5CF6).opacity(0.85)],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            Text(String(name.prefix(1)).uppercased())
                .font(.system(size: size * 0.42, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
        }
    }
}

/// 空状态
struct GCEmpty: View {
    let icon: String
    let title: String
    var subtitle: String = ""

    var body: some View {
        VStack(spacing: 10) {
            Image(systemName: icon)
                .font(.system(size: 34, weight: .light))
                .foregroundStyle(.secondary)
            Text(title).font(.system(size: 15, weight: .semibold))
            if !subtitle.isEmpty {
                Text(subtitle).font(.system(size: 13)).foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 60)
    }
}
