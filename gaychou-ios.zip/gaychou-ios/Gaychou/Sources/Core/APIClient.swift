import Foundation
#if canImport(UIKit)
import UIKit
#endif

// MARK: - 错误

enum APIError: LocalizedError {
    case server(String)
    case unauthorized(String)
    case network(String)
    case decoding(String)

    var errorDescription: String? {
        switch self {
        case .server(let m), .unauthorized(let m), .network(let m), .decoding(let m): return m
        }
    }

    var isAuthIssue: Bool {
        if case .unauthorized = self { return true }
        return false
    }
}

// MARK: - Token 存储

enum TokenStore {
    private static let key = "gc.auth.token"
    private static let userKey = "gc.auth.user"

    static var token: String? {
        get { UserDefaults.standard.string(forKey: key) }
        set {
            if let v = newValue, !v.isEmpty { UserDefaults.standard.set(v, forKey: key) }
            else { UserDefaults.standard.removeObject(forKey: key) }
        }
    }

    static func save(user: User?) {
        guard let user, let data = try? JSONEncoder().encode(user) else {
            UserDefaults.standard.removeObject(forKey: userKey)
            return
        }
        UserDefaults.standard.set(data, forKey: userKey)
    }

    static func loadUser() -> User? {
        guard let data = UserDefaults.standard.data(forKey: userKey) else { return nil }
        return try? JSONDecoder().decode(User.self, from: data)
    }
}

// MARK: - 客户端

final class APIClient {
    static let shared = APIClient()
    static let baseURL = URL(string: "https://aly.gaychou.top/api.php")!

    private let session: URLSession
    private let decoder = JSONDecoder()

    private init() {
        let cfg = URLSessionConfiguration.default
        cfg.timeoutIntervalForRequest = 20
        cfg.timeoutIntervalForResource = 40
        cfg.requestCachePolicy = .reloadIgnoringLocalCacheData
        // 与网页同域：保留 cookie，登录的人机验证题（存 session）才能对上
        cfg.httpCookieAcceptPolicy = .always
        cfg.httpShouldSetCookies = true
        session = URLSession(configuration: cfg)
    }

    // MARK: 公共请求

    func get<T: Decodable>(_ route: String, _ params: [String: String] = [:]) async throws -> T {
        try await send(route: route, params: params, method: "GET", body: nil)
    }

    func post<T: Decodable>(_ route: String, _ body: [String: String] = [:]) async throws -> T {
        try await send(route: route, params: [:], method: "POST", body: body)
    }

    // MARK: 具体接口

    func bootstrap() async throws -> BootstrapResponse {
        try await get("bootstrap")
    }

    func challenge() async throws -> ChallengeResponse {
        try await get("challenge")
    }

    func login(username: String, password: String, human: String) async throws -> AuthResponse {
        try await post("login", ["username": username, "password": password, "human": human, "remember": "1", "device": deviceName])
    }

    func register(username: String, email: String, code: String, password: String) async throws -> AuthResponse {
        try await post("register", ["username": username, "email": email, "code": code, "password": password, "agree": "1", "device": deviceName])
    }

    func sendCode(email: String, human: String) async throws -> SimpleOK {
        try await post("sendcode", ["email": email, "human": human])
    }

    func logout() async throws {
        let _: SimpleOK = try await post("logout")
    }

    func me() async throws -> MeResponse {
        try await get("me")
    }

    func feed(tab: String, page: Int) async throws -> FeedResponse {
        try await get("feed", ["tab": tab, "page": String(page)])
    }

    func script(id: Int) async throws -> ScriptDetailResponse {
        try await get("script", ["id": String(id)])
    }

    func thread(id: Int) async throws -> ThreadDetailResponse {
        try await get("thread", ["id": String(id)])
    }

    func resource(id: Int) async throws -> ResourceDetailResponse {
        try await get("resource", ["id": String(id)])
    }

    func search(_ q: String) async throws -> SearchResponse {
        try await get("search", ["q": q])
    }

    func like(id: Int) async throws -> LikeResponse {
        try await post("like", ["id": String(id)])
    }

    func comment(scriptID: Int, content: String) async throws -> SimpleOK {
        try await post("comment", ["id": String(scriptID), "content": content])
    }

    func reply(threadID: Int, content: String) async throws -> SimpleOK {
        try await post("reply", ["id": String(threadID), "content": content])
    }

    func newThread(title: String, content: String, tag: String) async throws -> SimpleOK {
        try await post("newthread", ["title": title, "content": content, "tag": tag])
    }

    // MARK: 底层

    private var deviceName: String {
        #if canImport(UIKit)
        return "\(UIDeviceModel.name) / iOS \(ProcessInfo.processInfo.operatingSystemVersionString)"
        #else
        return "iOS App"
        #endif
    }

    private func send<T: Decodable>(route: String,
                                    params: [String: String],
                                    method: String,
                                    body: [String: String]?) async throws -> T {
        var comps = URLComponents(url: Self.baseURL, resolvingAgainstBaseURL: false)!
        var items = comps.queryItems ?? []
        items.append(URLQueryItem(name: "r", value: route))
        for (k, v) in params { items.append(URLQueryItem(name: k, value: v)) }
        comps.queryItems = items
        guard let url = comps.url else { throw APIError.network("请求地址无效") }

        var req = URLRequest(url: url)
        req.httpMethod = method
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        if let token = TokenStore.token {
            req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        if let body {
            req.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
            req.httpBody = try? JSONSerialization.data(withJSONObject: body)
        }

        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await session.data(for: req)
        } catch {
            throw APIError.network("网络连接失败，请检查网络后重试")
        }

        let status = (response as? HTTPURLResponse)?.statusCode ?? 0

        if let err = try? decoder.decode(APIErrorBody.self, from: data), err.ok == false {
            let msg = err.error ?? "请求失败"
            if status == 401 || err.login == true { throw APIError.unauthorized(msg) }
            throw APIError.server(msg)
        }

        guard (200..<300).contains(status) else {
            throw APIError.server("服务异常（HTTP \(status)）")
        }

        do {
            return try decoder.decode(T.self, from: data)
        } catch {
            throw APIError.decoding("数据格式异常")
        }
    }
}

enum UIDeviceModel {
    static var name: String {
        #if canImport(UIKit)
        return UIDevice.current.model
        #else
        return "Device"
        #endif
    }
}
