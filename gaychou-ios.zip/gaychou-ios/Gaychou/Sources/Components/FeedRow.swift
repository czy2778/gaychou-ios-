import SwiftUI

struct FeedRow: View {
    let item: FeedItem

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            VStack(alignment: .leading, spacing: 7) {
                badges

                Text(item.title)
                    .font(.system(size: 15.5, weight: .semibold))
                    .foregroundStyle(.primary)
                    .lineLimit(2)
                    .multilineTextAlignment(.leading)

                if !item.excerpt.isEmpty {
                    Text(item.excerpt)
                        .font(.system(size: 13))
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                        .multilineTextAlignment(.leading)
                }

                HStack(spacing: 6) {
                    AvatarView(url: item.avatar, name: item.author.name, size: 18)
                    Text(item.author.name)
                        .font(.system(size: 12, weight: .medium))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                    Text("·").font(.system(size: 12)).foregroundStyle(.tertiary)
                    Text(item.ago)
                        .font(.system(size: 12))
                        .foregroundStyle(.tertiary)

                    Spacer(minLength: 6)

                    metric("hand.thumbsup", item.likes)
                    metric(item.kind == .thread ? "bubble.left" : "text.bubble", item.comments)
                }
                .padding(.top, 1)
            }

            if !item.image.isEmpty, let u = URL(string: item.image) {
                AsyncImage(url: u) { phase in
                    if let img = phase.image {
                        img.resizable().scaledToFill()
                    } else {
                        RoundedRectangle(cornerRadius: 12).fill(Color.primary.opacity(0.05))
                    }
                }
                .frame(width: 68, height: 68)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
        }
        .padding(14)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .strokeBorder(Color.white.opacity(0.16), lineWidth: 0.7)
        )
        .shadow(color: .black.opacity(0.05), radius: 10, y: 5)
    }

    private var badges: some View {
        HStack(spacing: 5) {
            Pill(text: kindText, color: kindColor, filled: true)
            if item.pinned { Pill(text: "置顶", color: GC.amber) }
            if item.solved { Pill(text: "已解决", color: GC.mint) }
            if !item.tag.isEmpty, item.kind != .script { Pill(text: item.tag, color: GC.purple) }
        }
    }

    private var kindText: String {
        switch item.kind {
        case .script: return "脚本"
        case .thread: return "提问"
        case .resource: return "资源"
        }
    }

    private var kindColor: Color {
        switch item.kind {
        case .script: return GC.blue
        case .thread: return GC.purple
        case .resource: return GC.mint
        }
    }

    private func metric(_ icon: String, _ n: Int) -> some View {
        HStack(spacing: 3) {
            Image(systemName: icon).font(.system(size: 10.5))
            Text("\(n)").font(.system(size: 11, weight: .medium))
        }
        .foregroundStyle(.tertiary)
    }
}
