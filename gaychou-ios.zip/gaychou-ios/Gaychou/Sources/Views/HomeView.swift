import SwiftUI

enum FeedTab: String, CaseIterable, Identifiable {
    case script, ask, resource
    var id: String { rawValue }
    var title: String {
        switch self {
        case .script: return "脚本"
        case .ask: return "提问"
        case .resource: return "资源"
        }
    }
}

struct HomeView: View {
    var onNeedLogin: () -> Void
    @StateObject private var session = Session.shared
    @ObservedObject private var refreshSignal = FeedRefresh.shared

    @State private var tab: FeedTab = .script
    @State private var items: [FeedItem] = []
    @State private var page = 1
    @State private var more = true
    @State private var loading = false
    @State private var firstLoad = true
    @State private var error: String?
    @State private var path = NavigationPath()

    var body: some View {
        NavigationStack(path: $path) {
            VStack(spacing: 0) {
                header
                segment
                content
            }
            .navigationDestination(for: FeedItem.self) { item in
                DetailHost(item: item, onNeedLogin: onNeedLogin)
            }
            .navigationDestination(for: Route.self) { r in
                switch r {
                case .login: LoginView()
                case .compose: ComposeView()
                }
            }
        }
        .task {
            if firstLoad { await reload() }
        }
        .onChange(of: tab) { _ in
            Task { await reload() }
        }
        .onChange(of: path.count) { UINav.shared.homeDepth = $0 }
        .onChange(of: refreshSignal.stamp) { _ in
            tab = .ask
            Task { await reload() }
        }
    }

    // MARK: 头部

    private var header: some View {
        HStack(spacing: 10) {
            ZStack {
                RoundedRectangle(cornerRadius: 11, style: .continuous)
                    .fill(LinearGradient(colors: [GC.blue, Color(hex: 0x6B5CF6)],
                                         startPoint: .topLeading, endPoint: .bottomTrailing))
                Text("g")
                    .font(.system(size: 20, weight: .heavy, design: .rounded))
                    .foregroundStyle(.white)
            }
            .frame(width: 34, height: 34)

            VStack(alignment: .leading, spacing: 0) {
                Text(session.siteName)
                    .font(.system(size: 18, weight: .bold, design: .rounded))
                Text("脚本 · 提问 · 资源")
                    .font(.system(size: 10.5))
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Button {
                path.append(Route.compose)
            } label: {
                Image(systemName: "square.and.pencil")
                    .font(.system(size: 16, weight: .medium))
                    .foregroundStyle(Color.gcBlue)
                    .frame(width: 36, height: 36)
                    .background(Circle().fill(Color.gcBlue.opacity(0.10)))
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 18)
        .padding(.top, 4)
        .padding(.bottom, 10)
    }

    // MARK: 分段

    @Namespace private var segNS

    private var segment: some View {
        HStack(spacing: 4) {
            ForEach(FeedTab.allCases) { t in
                Button {
                    withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) { tab = t }
                } label: {
                    Text(t.title)
                        .font(.system(size: 13.5, weight: tab == t ? .semibold : .medium))
                        .foregroundStyle(tab == t ? Color.primary : Color.secondary)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 8)
                        .background {
                            if tab == t {
                                Capsule()
                                    .fill(Color(.systemBackground).opacity(0.88))
                                    .matchedGeometryEffect(id: "seg", in: segNS)
                                    .shadow(color: .black.opacity(0.08), radius: 5, y: 2)
                            }
                        }
                }
                .buttonStyle(.plain)
            }
        }
        .padding(4)
        .background(Capsule().fill(Color.primary.opacity(0.055)))
        .padding(.horizontal, 18)
        .padding(.bottom, 8)
    }

    // MARK: 列表

    private var content: some View {
        ScrollView {
            LazyVStack(spacing: 10) {
                if firstLoad && loading {
                    ForEach(0..<4, id: \.self) { _ in SkeletonRow() }
                } else if let error, items.isEmpty {
                    GCEmpty(icon: "wifi.exclamationmark", title: "加载失败", subtitle: error)
                        .padding(.top, 40)
                    Button("重试") { Task { await reload() } }
                        .buttonStyle(.borderedProminent)
                        .tint(.gcBlue)
                } else if items.isEmpty {
                    GCEmpty(icon: "tray", title: "还没有内容",
                            subtitle: "下拉刷新试试，或者点右上角发第一条")
                        .padding(.top, 40)
                } else {
                    ForEach(items) { item in
                        NavigationLink(value: item) {
                            FeedRow(item: item)
                        }
                        .buttonStyle(.plain)
                        .onAppear {
                            if item.id == items.last?.id { Task { await loadMore() } }
                        }
                    }

                    if loading && !firstLoad {
                        ProgressView().padding(.vertical, 14)
                    } else if !more {
                        Text("— 到底了 —")
                            .font(.system(size: 11.5))
                            .foregroundStyle(.tertiary)
                            .padding(.vertical, 16)
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 96)
            .padding(.top, 2)
        }
        .scrollIndicators(.hidden)
        .refreshable { await reload() }
    }

    // MARK: 数据

    private func reload() async {
        let want = tab.rawValue
        page = 1
        more = true
        error = nil
        loading = true
        do {
            let r = try await APIClient.shared.feed(tab: want, page: 1)
            if r.tab == want {
                items = r.items
                more = r.more
                page = 1
            }
        } catch let e {
            if tab.rawValue == want {
                self.error = e.localizedDescription
                items = []
            }
        }
        loading = false
        firstLoad = false
    }

    private func loadMore() async {
        guard more, !loading else { return }
        loading = true
        let next = page + 1
        do {
            let r = try await APIClient.shared.feed(tab: tab.rawValue, page: next)
            if r.tab == tab.rawValue {
                let known = Set(items.map(\.id))
                items += r.items.filter { !known.contains($0.id) }
                more = r.more
                page = next
            }
        } catch {
            more = false
        }
        loading = false
    }
}

// MARK: - 路由

enum Route: Hashable {
    case login
    case compose
}

// MARK: - 骨架屏

struct SkeletonRow: View {
    @State private var pulse = false

    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            RoundedRectangle(cornerRadius: 5).frame(width: 46, height: 16)
            RoundedRectangle(cornerRadius: 5).frame(height: 15)
            RoundedRectangle(cornerRadius: 5).frame(width: 210, height: 12)
            HStack(spacing: 6) {
                Circle().frame(width: 18, height: 18)
                RoundedRectangle(cornerRadius: 4).frame(width: 70, height: 10)
                Spacer()
            }
        }
        .foregroundStyle(Color.primary.opacity(0.07))
        .padding(14)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .opacity(pulse ? 0.55 : 1)
        .onAppear {
            withAnimation(.easeInOut(duration: 0.9).repeatForever(autoreverses: true)) { pulse = true }
        }
    }
}
