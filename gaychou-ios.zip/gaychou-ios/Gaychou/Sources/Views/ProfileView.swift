import SwiftUI

struct ProfileView: View {
    var onNeedLogin: () -> Void = {}
    @StateObject private var session = Session.shared

    @State private var counts = MeResponse.Counts(scripts: 0, threads: 0)
    @State private var showLogin = false
    @State private var confirmLogout = false
    @State private var toast: String?

    private let base = "https://aly.gaychou.top"

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 14) {
                    profileCard
                    if session.isLoggedIn {
                        statsCard
                        menuCard
                        logoutButton
                    } else {
                        guestCard
                    }
                    footer
                }
                .padding(.horizontal, 16)
                .padding(.top, 8)
                .padding(.bottom, 100)
            }
            .scrollIndicators(.hidden)
            .background(GlassBackground())
            .navigationTitle("我的")
            .navigationBarTitleDisplayMode(.inline)
            .sheet(isPresented: $showLogin) { LoginView() }
            .task(id: session.user?.id) { await loadCounts() }
            .onChange(of: session.isLoggedIn) { loggedIn in
                if loggedIn { Task { await loadCounts() } } else { counts = MeResponse.Counts(scripts: 0, threads: 0) }
            }
        }
    }

    // MARK: 顶部

    private var profileCard: some View {
        VStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(LinearGradient(colors: [GC.blue.opacity(0.22), Color(hex: 0x6B5CF6).opacity(0.22)],
                                         startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 96, height: 96)
                    .blur(radius: 10)
                AvatarView(url: session.user?.avatar ?? "", name: session.user?.name ?? "游客", size: 78)
            }

            VStack(spacing: 4) {
                Text(session.user?.name ?? "未登录")
                    .font(.system(size: 19, weight: .bold, design: .rounded))
                if let u = session.user {
                    HStack(spacing: 6) {
                        Pill(text: u.role == "owner" ? "站长" : (u.isAdmin ? "管理员" : "成员"),
                             color: u.isAdmin ? GC.amber : GC.blue, filled: true)
                        if !u.email.isEmpty {
                            Text(u.email).font(.system(size: 11.5)).foregroundStyle(.secondary).lineLimit(1)
                        }
                    }
                } else {
                    Text("登录后同步你的帖子、评论和点赞")
                        .font(.system(size: 12.5)).foregroundStyle(.secondary)
                }
            }

            if !session.isLoggedIn {
                Button {
                    showLogin = true
                } label: {
                    Text("登录 / 注册")
                        .font(.system(size: 14.5, weight: .semibold))
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity).frame(height: 44)
                        .background(
                            RoundedRectangle(cornerRadius: 13, style: .continuous)
                                .fill(LinearGradient(colors: [GC.blue, Color(hex: 0x6B5CF6)],
                                                     startPoint: .leading, endPoint: .trailing))
                        )
                }
                .buttonStyle(.plain)
                .padding(.top, 2)
            }
        }
        .padding(.vertical, 20)
        .padding(.horizontal, 16)
        .frame(maxWidth: .infinity)
        .glassCard(padding: 0)
    }

    private var statsCard: some View {
        HStack(spacing: 0) {
            StatCell(value: "\(counts.scripts)", label: "脚本")
            Divider().frame(height: 26).opacity(0.4)
            StatCell(value: "\(counts.threads)", label: "提问")
            Divider().frame(height: 26).opacity(0.4)
            StatCell(value: "1.0.0", label: "版本")
        }
        .padding(.vertical, 14)
        .glassCard(padding: 0)
    }

    private var menuCard: some View {
        VStack(spacing: 0) {
            row(icon: "square.stack.3d.up", title: "我的脚本", tint: GC.blue, url: "\(base)/me.php")
            divider
            row(icon: "text.bubble", title: "我的提问", tint: GC.purple, url: "\(base)/forum.php?mine=1")
            divider
            row(icon: "bell", title: "消息通知", tint: GC.mint, url: "\(base)/notifications.php")
            divider
            row(icon: "gearshape", title: "账号设置", tint: GC.amber, url: "\(base)/settings.php")
        }
        .glassCard(padding: 0)
    }

    private var guestCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("为什么要登录？", systemImage: "sparkles")
                .font(.system(size: 13.5, weight: .semibold))
            bullet("点赞、评论、回帖")
            bullet("发提问帖，和站内的人一起解决")
            bullet("和网页端共用同一个账号，数据实时同步")
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .glassCard(padding: 0)
    }

    private var logoutButton: some View {
        Button {
            confirmLogout = true
        } label: {
            Text("退出登录")
                .font(.system(size: 14.5, weight: .semibold))
                .foregroundStyle(Color(hex: 0xE5484D))
                .frame(maxWidth: .infinity).frame(height: 46)
                .background(RoundedRectangle(cornerRadius: 14).fill(Color(hex: 0xE5484D).opacity(0.10)))
        }
        .buttonStyle(.plain)
        .confirmationDialog("确定退出登录？", isPresented: $confirmLogout, titleVisibility: .visible) {
            Button("退出", role: .destructive) { session.signOut() }
            Button("取消", role: .cancel) {}
        }
    }

    private var footer: some View {
        VStack(spacing: 4) {
            Text("\(session.siteName) for iOS")
                .font(.system(size: 11.5, weight: .medium))
                .foregroundStyle(.tertiary)
            Text("与网页端共用同一数据库")
                .font(.system(size: 10.5))
                .foregroundStyle(.quaternary)
        }
        .padding(.top, 10)
    }

    private var divider: some View {
        Divider().opacity(0.35).padding(.leading, 52)
    }

    private func row(icon: String, title: String, tint: Color, url: String) -> some View {
        Button {
            if let u = URL(string: url) { UIApplication.shared.open(u) }
        } label: {
            HStack(spacing: 12) {
                Image(systemName: icon)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundStyle(tint)
                    .frame(width: 28, height: 28)
                    .background(RoundedRectangle(cornerRadius: 8).fill(tint.opacity(0.12)))
                Text(title).font(.system(size: 14.5))
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(.quaternary)
            }
            .padding(.horizontal, 14).padding(.vertical, 12)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    private func bullet(_ text: String) -> some View {
        HStack(alignment: .top, spacing: 8) {
            Circle().fill(GC.blue.opacity(0.6)).frame(width: 5, height: 5).padding(.top, 6)
            Text(text).font(.system(size: 13)).foregroundStyle(.secondary)
            Spacer(minLength: 0)
        }
    }

    private func loadCounts() async {
        guard session.isLoggedIn else { return }
        do {
            let r = try await APIClient.shared.me()
            counts = r.counts
        } catch {
        }
    }
}
