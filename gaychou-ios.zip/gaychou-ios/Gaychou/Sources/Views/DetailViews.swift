import SwiftUI
import UIKit

// MARK: - 详情分发

struct DetailHost: View {
    let item: FeedItem
    var onNeedLogin: () -> Void = {}

    var body: some View {
        switch item.kind {
        case .script:
            ScriptDetailView(id: item.id, fallback: item, onNeedLogin: onNeedLogin)
        case .thread:
            ThreadDetailView(id: item.id, fallback: item, onNeedLogin: onNeedLogin)
        case .resource:
            ResourceDetailView(id: item.id, fallback: item)
        }
    }
}

// MARK: - 脚本详情

struct ScriptDetailView: View {
    let id: Int
    let fallback: FeedItem
    var onNeedLogin: () -> Void

    @State private var data: ScriptDetailResponse?
    @State private var error: String?
    @State private var liked: Bool = false
    @State private var likes: Int = 0
    @State private var draft: String = ""
    @State private var sending = false
    @State private var toast: String?
    @State private var showLogin = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                headerCard
                if let data {
                    if data.locked {
                        lockedCard
                    } else if !data.content.isEmpty {
                        codeCard(data.content)
                    }
                    commentSection(data)
                } else if let error {
                    GCEmpty(icon: "exclamationmark.triangle", title: "加载失败", subtitle: error)
                } else {
                    ProgressView().frame(maxWidth: .infinity).padding(.top, 60)
                }
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 20)
        }
        .scrollIndicators(.hidden)
        .background(GlassBackground())
        .navigationTitle("脚本详情")
        .navigationBarTitleDisplayMode(.inline)
        .safeAreaInset(edge: .bottom) { composer }
        .overlay(alignment: .top) { toastView }
        .task { await load() }
        .sheet(isPresented: $showLogin) { LoginView() }
    }

    // MARK: 头部

    private var item: FeedItem { data?.item ?? fallback }

    private var headerCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 5) {
                Pill(text: "脚本", color: GC.blue, filled: true)
                if item.pinned { Pill(text: "置顶", color: GC.amber) }
            }

            Text(item.title)
                .font(.system(size: 20, weight: .bold))
                .fixedSize(horizontal: false, vertical: true)

            HStack(spacing: 8) {
                AvatarView(url: item.avatar, name: item.author.name, size: 30)
                VStack(alignment: .leading, spacing: 1) {
                    Text(item.author.name).font(.system(size: 13, weight: .semibold))
                    Text(item.ago).font(.system(size: 11.5)).foregroundStyle(.secondary)
                }
                Spacer()
                Button {
                    Task { await toggleLike() }
                } label: {
                    HStack(spacing: 5) {
                        Image(systemName: liked ? "hand.thumbsup.fill" : "hand.thumbsup")
                        Text("\(likes)")
                    }
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(liked ? Color.gcBlue : Color.secondary)
                    .padding(.horizontal, 12).padding(.vertical, 7)
                    .background(Capsule().fill((liked ? Color.gcBlue : Color.primary).opacity(0.10)))
                }
                .buttonStyle(.plain)
            }

            if let d = data, !d.description.isEmpty {
                Text(d.description)
                    .font(.system(size: 14))
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard(padding: 0)
        .padding(0)
    }

    private var lockedCard: some View {
        HStack(spacing: 10) {
            Image(systemName: "lock.fill").foregroundStyle(GC.amber)
            Text("作者未公开源码，仅作者本人可见")
                .font(.system(size: 13))
                .foregroundStyle(.secondary)
            Spacer()
        }
        .padding(14)
        .frame(maxWidth: .infinity)
        .background(RoundedRectangle(cornerRadius: 16).fill(GC.amber.opacity(0.10)))
    }

    private func codeCard(_ code: String) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Label("源码", systemImage: "chevron.left.forwardslash.chevron.right")
                    .font(.system(size: 12.5, weight: .semibold))
                    .foregroundStyle(.secondary)
                Spacer()
                Button {
                    UIPasteboard.general.string = code
                    flash("已复制源码")
                } label: {
                    Label("复制", systemImage: "doc.on.doc")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundStyle(Color.gcBlue)
                }
                .buttonStyle(.plain)
            }
            ScrollView(.horizontal) {
                Text(code)
                    .font(.system(size: 12, design: .monospaced))
                    .textSelection(.enabled)
                    .padding(12)
            }
            .frame(maxHeight: 320)
            .background(RoundedRectangle(cornerRadius: 12).fill(Color.primary.opacity(0.045)))
        }
        .padding(14)
        .glassCard(padding: 0)
    }

    // MARK: 评论

    private func commentSection(_ d: ScriptDetailResponse) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("评论").font(.system(size: 15, weight: .bold))
                Text("\(d.totalComments)")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(.secondary)
                Spacer()
            }

            if d.comments.isEmpty {
                Text("还没有评论，来说两句")
                    .font(.system(size: 13))
                    .foregroundStyle(.tertiary)
                    .padding(.vertical, 16)
                    .frame(maxWidth: .infinity)
            } else {
                ForEach(d.comments) { c in
                    HStack(alignment: .top, spacing: 10) {
                        AvatarView(url: c.avatar, name: c.name, size: 30)
                        VStack(alignment: .leading, spacing: 3) {
                            HStack(spacing: 6) {
                                Text(c.name).font(.system(size: 12.5, weight: .semibold))
                                Text(c.ago).font(.system(size: 11)).foregroundStyle(.tertiary)
                            }
                            Text(c.content)
                                .font(.system(size: 13.5))
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        Spacer(minLength: 0)
                    }
                    .padding(12)
                    .background(RoundedRectangle(cornerRadius: 14).fill(Color.primary.opacity(0.035)))
                }
            }
        }
        .padding(14)
        .glassCard(padding: 0)
    }

    // MARK: 输入条

    private var composer: some View {
        HStack(spacing: 8) {
            TextField("写评论…", text: $draft, axis: .vertical)
                .lineLimit(1...4)
                .font(.system(size: 14))
                .padding(.horizontal, 14)
                .padding(.vertical, 10)
                .background(Capsule().fill(Color.primary.opacity(0.06)))

            Button {
                Task { await sendComment() }
            } label: {
                Image(systemName: sending ? "ellipsis" : "arrow.up")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 38, height: 38)
                    .background(Circle().fill(draft.trimmingCharacters(in: .whitespaces).isEmpty ? Color.gray.opacity(0.4) : Color.gcBlue))
            }
            .buttonStyle(.plain)
            .disabled(sending || draft.trimmingCharacters(in: .whitespaces).isEmpty)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 8)
        .background(.ultraThinMaterial)
        .overlay(alignment: .top) { Divider().opacity(0.3) }
    }

    private var toastView: some View {
        Group {
            if let toast {
                Text(toast)
                    .font(.system(size: 12.5, weight: .medium))
                    .padding(.horizontal, 14).padding(.vertical, 8)
                    .background(Capsule().fill(.ultraThinMaterial))
                    .padding(.top, 6)
                    .transition(.move(edge: .top).combined(with: .opacity))
            }
        }
        .animation(.easeInOut(duration: 0.2), value: toast)
    }

    // MARK: 行为

    private func load() async {
        do {
            let d = try await APIClient.shared.script(id: id)
            data = d
            liked = d.liked
            likes = d.item.likes
        } catch let e {
            error = e.localizedDescription
        }
    }

    private func toggleLike() async {
        guard Session.shared.isLoggedIn else { showLogin = true; return }
        do {
            let r = try await APIClient.shared.like(id: id)
            liked = r.liked
            likes = r.likes
        } catch let e {
            flash(e.localizedDescription)
        }
    }

    private func sendComment() async {
        guard Session.shared.isLoggedIn else { showLogin = true; return }
        let text = draft.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        sending = true
        do {
            _ = try await APIClient.shared.comment(scriptID: id, content: text)
            draft = ""
            hideKeyboard()
            await load()
        } catch let e {
            flash(e.localizedDescription)
        }
        sending = false
    }

    private func flash(_ msg: String) {
        toast = msg
        Task {
            try? await Task.sleep(nanoseconds: 1_600_000_000)
            toast = nil
        }
    }
}

// MARK: - 提问详情

struct ThreadDetailView: View {
    let id: Int
    let fallback: FeedItem
    var onNeedLogin: () -> Void

    @State private var data: ThreadDetailResponse?
    @State private var error: String?
    @State private var draft = ""
    @State private var sending = false
    @State private var showLogin = false
    @State private var toast: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                if let d = data {
                    headCard(d)
                    bodyCard(d.content)
                    repliesCard(d)
                } else if let error {
                    GCEmpty(icon: "exclamationmark.triangle", title: "加载失败", subtitle: error)
                } else {
                    ProgressView().frame(maxWidth: .infinity).padding(.top, 60)
                }
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 20)
        }
        .scrollIndicators(.hidden)
        .background(GlassBackground())
        .navigationTitle("提问详情")
        .navigationBarTitleDisplayMode(.inline)
        .safeAreaInset(edge: .bottom) { composer }
        .overlay(alignment: .top) {
            if let toast {
                Text(toast).font(.system(size: 12.5, weight: .medium))
                    .padding(.horizontal, 14).padding(.vertical, 8)
                    .background(Capsule().fill(.ultraThinMaterial))
                    .padding(.top, 6)
            }
        }
        .task { await load() }
        .sheet(isPresented: $showLogin) { LoginView() }
    }

    private func headCard(_ d: ThreadDetailResponse) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 5) {
                Pill(text: "提问", color: GC.purple, filled: true)
                if d.item.solved { Pill(text: "已解决", color: GC.mint) }
                if !d.tagName.isEmpty { Pill(text: d.tagName, color: Color.gray) }
            }
            Text(d.item.title)
                .font(.system(size: 19, weight: .bold))
                .fixedSize(horizontal: false, vertical: true)
            HStack(spacing: 8) {
                AvatarView(url: d.item.avatar, name: d.item.author.name, size: 28)
                Text(d.item.author.name).font(.system(size: 12.5, weight: .semibold))
                Text("·").foregroundStyle(.tertiary)
                Text(d.item.ago).font(.system(size: 12)).foregroundStyle(.secondary)
                Spacer()
                Label("\(d.item.views)", systemImage: "eye")
                    .font(.system(size: 11.5))
                    .foregroundStyle(.tertiary)
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard(padding: 0)
    }

    private func bodyCard(_ text: String) -> some View {
        Text(text)
            .font(.system(size: 14.5))
            .lineSpacing(4)
            .fixedSize(horizontal: false, vertical: true)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(16)
            .glassCard(padding: 0)
    }

    private func repliesCard(_ d: ThreadDetailResponse) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("回复").font(.system(size: 15, weight: .bold))
                Text("\(d.posts.count)").font(.system(size: 12, weight: .semibold)).foregroundStyle(.secondary)
                Spacer()
            }
            if d.posts.isEmpty {
                Text("还没有人回复，来帮个忙")
                    .font(.system(size: 13)).foregroundStyle(.tertiary)
                    .frame(maxWidth: .infinity).padding(.vertical, 16)
            } else {
                ForEach(d.posts) { p in
                    HStack(alignment: .top, spacing: 10) {
                        AvatarView(url: p.avatar, name: p.name, size: 30)
                        VStack(alignment: .leading, spacing: 4) {
                            HStack(spacing: 6) {
                                Text(p.name).font(.system(size: 12.5, weight: .semibold))
                                if p.accepted { Pill(text: "已采纳", color: GC.mint) }
                                Text(p.ago).font(.system(size: 11)).foregroundStyle(.tertiary)
                            }
                            Text(p.content)
                                .font(.system(size: 13.5))
                                .lineSpacing(3)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        Spacer(minLength: 0)
                    }
                    .padding(12)
                    .background(
                        RoundedRectangle(cornerRadius: 14)
                            .fill(p.accepted ? GC.mint.opacity(0.10) : Color.primary.opacity(0.035))
                    )
                }
            }
        }
        .padding(14)
        .glassCard(padding: 0)
    }

    private var composer: some View {
        HStack(spacing: 8) {
            TextField("写下你的回答…", text: $draft, axis: .vertical)
                .lineLimit(1...4)
                .font(.system(size: 14))
                .padding(.horizontal, 14).padding(.vertical, 10)
                .background(Capsule().fill(Color.primary.opacity(0.06)))
            Button {
                Task { await send() }
            } label: {
                Image(systemName: sending ? "ellipsis" : "arrow.up")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 38, height: 38)
                    .background(Circle().fill(draft.trimmingCharacters(in: .whitespaces).isEmpty ? Color.gray.opacity(0.4) : GC.purple))
            }
            .buttonStyle(.plain)
            .disabled(sending || draft.trimmingCharacters(in: .whitespaces).isEmpty)
        }
        .padding(.horizontal, 14).padding(.vertical, 8)
        .background(.ultraThinMaterial)
        .overlay(alignment: .top) { Divider().opacity(0.3) }
    }

    private func load() async {
        do { data = try await APIClient.shared.thread(id: id) }
        catch let e { error = e.localizedDescription }
    }

    private func send() async {
        guard Session.shared.isLoggedIn else { showLogin = true; return }
        let text = draft.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        sending = true
        do {
            _ = try await APIClient.shared.reply(threadID: id, content: text)
            draft = ""
            hideKeyboard()
            await load()
        } catch let e {
            toast = e.localizedDescription
            Task { try? await Task.sleep(nanoseconds: 1_600_000_000); toast = nil }
        }
        sending = false
    }
}

// MARK: - 资源详情

struct ResourceDetailView: View {
    let id: Int
    let fallback: FeedItem

    @State private var data: ResourceDetailResponse?
    @State private var error: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                if let d = data {
                    if !d.item.image.isEmpty, let u = URL(string: d.item.image) {
                        AsyncImage(url: u) { p in
                            if let img = p.image { img.resizable().scaledToFill() }
                            else { Color.primary.opacity(0.05) }
                        }
                        .frame(height: 168)
                        .frame(maxWidth: .infinity)
                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                    }
                    headCard(d)
                    if !d.description.isEmpty { bodyCard(d.description) }
                    filesCard(d)
                } else if let error {
                    GCEmpty(icon: "exclamationmark.triangle", title: "加载失败", subtitle: error)
                } else {
                    ProgressView().frame(maxWidth: .infinity).padding(.top, 60)
                }
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 24)
        }
        .scrollIndicators(.hidden)
        .background(GlassBackground())
        .navigationTitle("资源详情")
        .navigationBarTitleDisplayMode(.inline)
        .task { await load() }
    }

    private func headCard(_ d: ResourceDetailResponse) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 5) {
                Pill(text: "资源", color: GC.mint, filled: true)
                if d.item.pinned { Pill(text: "官方", color: GC.amber) }
            }
            Text(d.item.title)
                .font(.system(size: 19, weight: .bold))
                .fixedSize(horizontal: false, vertical: true)
            HStack(spacing: 8) {
                AvatarView(url: d.item.avatar, name: d.item.author.name, size: 26)
                Text(d.item.author.name).font(.system(size: 12.5, weight: .semibold))
                Text("·").foregroundStyle(.tertiary)
                Text(d.item.ago).font(.system(size: 12)).foregroundStyle(.secondary)
                Spacer()
                Label("\(d.item.views)", systemImage: "arrow.down.circle")
                    .font(.system(size: 11.5)).foregroundStyle(.tertiary)
            }
            if !d.tags.isEmpty {
                HStack(spacing: 6) {
                    ForEach(d.tags.prefix(4), id: \.self) { t in Pill(text: t, color: GC.purple) }
                }
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard(padding: 0)
    }

    private func bodyCard(_ text: String) -> some View {
        Text(text)
            .font(.system(size: 14.5))
            .lineSpacing(4)
            .fixedSize(horizontal: false, vertical: true)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(16)
            .glassCard(padding: 0)
    }

    private func filesCard(_ d: ResourceDetailResponse) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("文件（\(d.files.count)）").font(.system(size: 15, weight: .bold))
            ForEach(d.files) { f in
                HStack(spacing: 10) {
                    Image(systemName: iconFor(f.name))
                        .font(.system(size: 17))
                        .foregroundStyle(GC.blue)
                        .frame(width: 34, height: 34)
                        .background(RoundedRectangle(cornerRadius: 9).fill(Color.gcBlue.opacity(0.10)))
                    VStack(alignment: .leading, spacing: 2) {
                        Text(f.name).font(.system(size: 13, weight: .medium)).lineLimit(1)
                        Text("\(f.sizeText) · \(f.downloads) 次下载")
                            .font(.system(size: 11)).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button {
                        if let u = URL(string: f.url) { UIApplication.shared.open(u) }
                    } label: {
                        Text("下载")
                            .font(.system(size: 12.5, weight: .semibold))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 14).padding(.vertical, 7)
                            .background(Capsule().fill(GC.blue))
                    }
                    .buttonStyle(.plain)
                }
                .padding(10)
                .background(RoundedRectangle(cornerRadius: 12).fill(Color.primary.opacity(0.035)))
            }
        }
        .padding(14)
        .glassCard(padding: 0)
    }

    private func iconFor(_ name: String) -> String {
        let ext = (name as NSString).pathExtension.lowercased()
        switch ext {
        case "ipa": return "iphone"
        case "apk": return "apps.iphone"
        case "zip", "rar", "7z": return "doc.zipper"
        case "png", "jpg", "jpeg", "webp": return "photo"
        case "mp4", "mov": return "play.rectangle"
        default: return "doc"
        }
    }

    private func load() async {
        do { data = try await APIClient.shared.resource(id: id) }
        catch let e { error = e.localizedDescription }
    }
}
