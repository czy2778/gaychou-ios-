import SwiftUI

struct SearchView: View {
    var onNeedLogin: () -> Void = {}
    @StateObject private var session = Session.shared

    @State private var query = ""
    @State private var results: [FeedItem] = []
    @State private var searching = false
    @State private var error: String?
    @State private var path = NavigationPath()
    @FocusState private var focused: Bool

    var body: some View {
        NavigationStack(path: $path) {
            VStack(spacing: 0) {
                searchBar
                content
            }
            .navigationDestination(for: FeedItem.self) { item in
                DetailHost(item: item, onNeedLogin: onNeedLogin)
            }
        }
        .onChange(of: path.count) { UINav.shared.searchDepth = $0 }
        .task(id: query) {
            let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !q.isEmpty else {
                results = []
                error = nil
                return
            }
            try? await Task.sleep(nanoseconds: 320_000_000)
            guard !Task.isCancelled else { return }
            await search(q)
        }
    }

    private var searchBar: some View {
        HStack(spacing: 9) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 14, weight: .medium))
                .foregroundStyle(.secondary)
            TextField("搜索脚本、提问、资源", text: $query)
                .font(.system(size: 14.5))
                .focused($focused)
                .submitLabel(.search)
                .autocorrectionDisabled()
            if !query.isEmpty {
                Button {
                    query = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 14))
                        .foregroundStyle(.tertiary)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 14).padding(.vertical, 11)
        .background(Capsule().fill(Color.primary.opacity(0.06)))
        .padding(.horizontal, 18)
        .padding(.top, 6)
        .padding(.bottom, 10)
    }

    @ViewBuilder
    private var content: some View {
        ScrollView {
            VStack(spacing: 10) {
                if query.trimmingCharacters(in: .whitespaces).isEmpty {
                    hotTags
                } else if searching && results.isEmpty {
                    ProgressView().padding(.top, 50)
                } else if let error {
                    GCEmpty(icon: "exclamationmark.triangle", title: "搜索失败", subtitle: error)
                        .padding(.top, 30)
                } else if results.isEmpty {
                    GCEmpty(icon: "magnifyingglass", title: "没有找到相关内容",
                            subtitle: "换个关键词试试")
                        .padding(.top, 30)
                } else {
                    ForEach(results) { item in
                        NavigationLink(value: item) { FeedRow(item: item) }
                            .buttonStyle(.plain)
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 96)
        }
        .scrollIndicators(.hidden)
        .scrollDismissesKeyboard(.immediately)
    }

    private var hotTags: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("试试这些")
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(.secondary)
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 68), spacing: 8)],
                      alignment: .leading, spacing: 8) {
                ForEach(["脚本", "安装", "教程", "ipa", "报错", "资源"], id: \.self) { t in
                    Button {
                        query = t
                    } label: {
                        Text(t)
                            .font(.system(size: 13))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 7)
                            .background(Capsule().fill(Color.primary.opacity(0.06)))
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .glassCard(padding: 0)
        .padding(.top, 4)
    }

    private func search(_ q: String) async {
        searching = true
        error = nil
        do {
            let r = try await APIClient.shared.search(q)
            if query.trimmingCharacters(in: .whitespaces) == q { results = r.items }
        } catch let e {
            error = e.localizedDescription
        }
        searching = false
    }
}
