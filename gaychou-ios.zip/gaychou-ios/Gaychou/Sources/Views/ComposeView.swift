import SwiftUI

/// 发帖成功后的全局刷新信号
@MainActor
final class FeedRefresh: ObservableObject {
    static let shared = FeedRefresh()
    @Published var stamp = 0
    func fire() { stamp &+= 1 }
}

struct ComposeView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var session = Session.shared

    @State private var title = ""
    @State private var content = ""
    @State private var tag = "other"
    @State private var busy = false
    @State private var error: String?
    @State private var showLogin = false

    private var tags: [(String, String)] {
        let order = ["install", "script", "account", "pay", "bug", "other"]
        return order.compactMap { k in session.tags[k].map { (k, $0) } }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    if !session.isLoggedIn {
                        loginHint
                    }

                    VStack(alignment: .leading, spacing: 8) {
                        Text("标题").font(.system(size: 12.5, weight: .semibold)).foregroundStyle(.secondary)
                        TextField("一句话说清你的问题", text: $title, axis: .vertical)
                            .font(.system(size: 15.5, weight: .medium))
                            .lineLimit(1...3)
                            .padding(13)
                            .background(RoundedRectangle(cornerRadius: 13).fill(Color.primary.opacity(0.045)))
                    }
                    .padding(14)
                    .glassCard(padding: 0)

                    VStack(alignment: .leading, spacing: 9) {
                        Text("分类").font(.system(size: 12.5, weight: .semibold)).foregroundStyle(.secondary)
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 8) {
                                ForEach(tags, id: \.0) { k, name in
                                    Button {
                                        withAnimation(.easeInOut(duration: 0.15)) { tag = k }
                                    } label: {
                                        Text(name)
                                            .font(.system(size: 12.5, weight: tag == k ? .semibold : .regular))
                                            .foregroundStyle(tag == k ? .white : Color.secondary)
                                            .padding(.horizontal, 13).padding(.vertical, 7)
                                            .background(
                                                Capsule().fill(tag == k ? GC.purple : Color.primary.opacity(0.06))
                                            )
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                            .padding(.vertical, 2)
                        }
                    }
                    .padding(14)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .glassCard(padding: 0)

                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text("内容").font(.system(size: 12.5, weight: .semibold)).foregroundStyle(.secondary)
                            Spacer()
                            Text("\(content.count)/20000").font(.system(size: 11)).foregroundStyle(.tertiary)
                        }
                        TextEditor(text: $content)
                            .font(.system(size: 14.5))
                            .frame(minHeight: 170)
                            .scrollContentBackground(.hidden)
                            .padding(9)
                            .background(RoundedRectangle(cornerRadius: 13).fill(Color.primary.opacity(0.045)))
                    }
                    .padding(14)
                    .glassCard(padding: 0)

                    if let error {
                        HStack(spacing: 7) {
                            Image(systemName: "exclamationmark.circle.fill")
                            Text(error).font(.system(size: 12.5))
                            Spacer(minLength: 0)
                        }
                        .foregroundStyle(.red)
                        .padding(11)
                        .background(RoundedRectangle(cornerRadius: 11).fill(Color.red.opacity(0.10)))
                    }

                    Button {
                        Task { await submit() }
                    } label: {
                        HStack(spacing: 8) {
                            if busy { ProgressView().tint(.white) }
                            Text("发布提问")
                                .font(.system(size: 15, weight: .semibold))
                        }
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity).frame(height: 48)
                        .background(
                            RoundedRectangle(cornerRadius: 14, style: .continuous)
                                .fill(LinearGradient(colors: [GC.purple, Color(hex: 0x6B5CF6)],
                                                     startPoint: .leading, endPoint: .trailing))
                                .opacity(canSubmit ? 1 : 0.45)
                        )
                    }
                    .buttonStyle(.plain)
                    .disabled(!canSubmit || busy)

                    Text("脚本与资源请在网页端发布（支持源码编辑、封面上传、多文件）")
                        .font(.system(size: 11.5))
                        .foregroundStyle(.tertiary)
                        .frame(maxWidth: .infinity, alignment: .center)
                        .padding(.top, 4)
                }
                .padding(.horizontal, 18)
                .padding(.top, 8)
                .padding(.bottom, 30)
            }
            .scrollDismissesKeyboard(.interactively)
            .background(GlassBackground())
            .navigationTitle("发布")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
            }
            .sheet(isPresented: $showLogin) { LoginView() }
        }
    }

    private var loginHint: some View {
        HStack(spacing: 10) {
            Image(systemName: "person.crop.circle.badge.exclamationmark")
                .foregroundStyle(GC.amber)
            Text("登录后才能发帖").font(.system(size: 13))
            Spacer()
            Button("去登录") { showLogin = true }
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(Color.gcBlue)
        }
        .padding(13)
        .background(RoundedRectangle(cornerRadius: 13).fill(GC.amber.opacity(0.10)))
    }

    private var canSubmit: Bool {
        session.isLoggedIn && title.trimmingCharacters(in: .whitespaces).count >= 4
            && content.trimmingCharacters(in: .whitespaces).count >= 6
    }

    private func submit() async {
        busy = true
        error = nil
        do {
            _ = try await APIClient.shared.newThread(
                title: title.trimmingCharacters(in: .whitespacesAndNewlines),
                content: content.trimmingCharacters(in: .whitespacesAndNewlines),
                tag: tag
            )
            FeedRefresh.shared.fire()
            dismiss()
        } catch let e {
            error = e.localizedDescription
        }
        busy = false
    }
}
