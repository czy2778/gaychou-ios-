import SwiftUI
import UIKit

struct LoginView: View {
    enum Mode: String, CaseIterable { case signin = "登录", signup = "注册" }

    @Environment(\.dismiss) private var dismiss
    @StateObject private var session = Session.shared

    @State private var mode: Mode = .signin
    @State private var username = ""
    @State private var password = ""
    @State private var email = ""
    @State private var code = ""
    @State private var human = ""
    @State private var question = ""
    @State private var busy = false
    @State private var sending = false
    @State private var error: String?
    @State private var info: String?
    @State private var agree = true

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    brand
                    modeSwitch
                    form
                    if let error { banner(error, color: .red) }
                    if let info { banner(info, color: GC.mint) }
                    submit
                    hint
                }
                .padding(.horizontal, 22)
                .padding(.top, 12)
                .padding(.bottom, 30)
            }
            .scrollDismissesKeyboard(.interactively)
            .background(GlassBackground())
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("关闭") { dismiss() }
                }
            }
            .task { await refreshChallenge() }
            .onChange(of: mode) { _ in
                error = nil
                info = nil
                Task { await refreshChallenge() }
            }
        }
    }

    private var brand: some View {
        VStack(spacing: 8) {
            ZStack {
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .fill(LinearGradient(colors: [GC.blue, Color(hex: 0x6B5CF6)],
                                         startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 64, height: 64)
                Text("g").font(.system(size: 34, weight: .heavy, design: .rounded)).foregroundStyle(.white)
            }
            .shadow(color: GC.blue.opacity(0.35), radius: 14, y: 8)
            Text(session.siteName).font(.system(size: 20, weight: .bold, design: .rounded))
            Text(mode == .signin ? "登录后可以点赞、评论和发帖" : "注册一个账号，和网页端通用")
                .font(.system(size: 12.5)).foregroundStyle(.secondary)
        }
        .padding(.top, 6)
    }

    private var modeSwitch: some View {
        HStack(spacing: 4) {
            ForEach(Mode.allCases, id: \.self) { m in
                Button {
                    withAnimation(.easeInOut(duration: 0.2)) { mode = m }
                } label: {
                    Text(m.rawValue)
                        .font(.system(size: 14, weight: mode == m ? .semibold : .regular))
                        .foregroundStyle(mode == m ? Color.primary : Color.secondary)
                        .frame(maxWidth: .infinity).padding(.vertical, 9)
                        .background {
                            if mode == m {
                                Capsule().fill(.background.opacity(0.9))
                                    .shadow(color: .black.opacity(0.08), radius: 4, y: 2)
                            }
                        }
                }
                .buttonStyle(.plain)
            }
        }
        .padding(4)
        .background(Capsule().fill(Color.primary.opacity(0.06)))
    }

    @ViewBuilder
    private var form: some View {
        VStack(spacing: 10) {
            field("person", "用户名 / 邮箱", $username, keyboard: .default)
            secureField("lock", "密码", $password)

            if mode == .signup {
                field("envelope", "邮箱", $email, keyboard: .emailAddress)
                HStack(spacing: 8) {
                    field("number", "邮箱验证码", $code, keyboard: .numberPad)
                    Button {
                        Task { await sendCode() }
                    } label: {
                        Group {
                            if sending { ProgressView().scaleEffect(0.8) }
                            else { Text("发送验证码").font(.system(size: 12.5, weight: .semibold)) }
                        }
                        .foregroundStyle(.white)
                        .frame(width: 92, height: 44)
                        .background(RoundedRectangle(cornerRadius: 12).fill(GC.blue))
                    }
                    .buttonStyle(.plain)
                    .disabled(sending || email.isEmpty || human.isEmpty)
                }
            }

            humanField

            if mode == .signup {
                Button {
                    agree.toggle()
                } label: {
                    HStack(spacing: 7) {
                        Image(systemName: agree ? "checkmark.square.fill" : "square")
                            .foregroundStyle(agree ? Color.gcBlue : Color.secondary)
                        Text("我已阅读并同意《用户条款与免责声明》")
                            .font(.system(size: 12))
                            .foregroundStyle(.secondary)
                        Spacer()
                    }
                }
                .buttonStyle(.plain)
            }
        }
        .padding(14)
        .glassCard(padding: 0)
    }

    private var humanField: some View {
        HStack(spacing: 8) {
            Image(systemName: "checkmark.shield")
                .font(.system(size: 13))
                .foregroundStyle(GC.amber)
            Text(question.isEmpty ? "正在获取验证题…" : question)
                .font(.system(size: 13, weight: .medium))
                .foregroundStyle(.secondary)
            Spacer()
            TextField("答案", text: $human)
                .keyboardType(.numbersAndPunctuation)
                .multilineTextAlignment(.trailing)
                .font(.system(size: 14, weight: .semibold))
                .frame(width: 66)
            Button {
                Task { await refreshChallenge() }
            } label: {
                Image(systemName: "arrow.clockwise")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(Color.gcBlue)
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 12).padding(.vertical, 11)
        .background(RoundedRectangle(cornerRadius: 12).fill(Color.primary.opacity(0.045)))
    }

    private var submit: some View {
        Button {
            Task { await submitAction() }
        } label: {
            HStack(spacing: 8) {
                if busy { ProgressView().tint(.white) }
                Text(mode == .signin ? "登录" : "注册并登录")
                    .font(.system(size: 15, weight: .semibold))
            }
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .frame(height: 48)
            .background(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(LinearGradient(colors: [GC.blue, Color(hex: 0x6B5CF6)],
                                         startPoint: .leading, endPoint: .trailing))
                    .opacity(canSubmit ? 1 : 0.45)
            )
        }
        .buttonStyle(.plain)
        .disabled(!canSubmit || busy)
    }

    private var hint: some View {
        Text("账号与网页端完全通用，数据实时同步")
            .font(.system(size: 11.5))
            .foregroundStyle(.tertiary)
    }

    private var canSubmit: Bool {
        if username.isEmpty || password.isEmpty { return false }
        if mode == .signup { return !email.isEmpty && !code.isEmpty && agree }
        return !human.isEmpty
    }

    // MARK: 组件

    private func field(_ icon: String, _ placeholder: String,
                       _ text: Binding<String>, keyboard: UIKeyboardType) -> some View {
        HStack(spacing: 9) {
            Image(systemName: icon).font(.system(size: 13)).foregroundStyle(.secondary).frame(width: 18)
            TextField(placeholder, text: text)
                .font(.system(size: 14))
                .keyboardType(keyboard)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
        }
        .padding(.horizontal, 12).padding(.vertical, 12)
        .background(RoundedRectangle(cornerRadius: 12).fill(Color.primary.opacity(0.045)))
    }

    private func secureField(_ icon: String, _ placeholder: String, _ text: Binding<String>) -> some View {
        HStack(spacing: 9) {
            Image(systemName: icon).font(.system(size: 13)).foregroundStyle(.secondary).frame(width: 18)
            SecureField(placeholder, text: text).font(.system(size: 14))
        }
        .padding(.horizontal, 12).padding(.vertical, 12)
        .background(RoundedRectangle(cornerRadius: 12).fill(Color.primary.opacity(0.045)))
    }

    private func banner(_ text: String, color: Color) -> some View {
        HStack(spacing: 8) {
            Image(systemName: color == .red ? "exclamationmark.circle.fill" : "checkmark.circle.fill")
            Text(text).font(.system(size: 12.5))
            Spacer(minLength: 0)
        }
        .foregroundStyle(color)
        .padding(11)
        .background(RoundedRectangle(cornerRadius: 11).fill(color.opacity(0.10)))
    }

    // MARK: 行为

    private func refreshChallenge() async {
        human = ""
        do {
            question = try await APIClient.shared.challenge().question
        } catch {
            question = "验证题获取失败，点右侧刷新"
        }
    }

    private func submitAction() async {
        busy = true
        error = nil
        info = nil
        do {
            if mode == .signin {
                try await session.signIn(username: username, password: password, human: human)
            } else {
                try await session.signUp(username: username, email: email, code: code, password: password)
            }
            dismiss()
        } catch let e {
            error = e.localizedDescription
            await refreshChallenge()
        }
        busy = false
    }

    private func sendCode() async {
        sending = true
        error = nil
        do {
            _ = try await APIClient.shared.sendCode(email: email, human: human)
            info = "验证码已发送，请查收邮件（含垃圾箱）"
            await refreshChallenge()
        } catch let e {
            error = e.localizedDescription
            await refreshChallenge()
        }
        sending = false
    }
}
