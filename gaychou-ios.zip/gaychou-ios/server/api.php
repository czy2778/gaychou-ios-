<?php
declare(strict_types=1);
/**
 * api.php —— 移动端 JSON API（gayChou iOS App 使用）
 *
 * 与网页端共用同一数据库、同一套 users 表与 password_hash，不做任何数据分叉。
 * 鉴权：Authorization: Bearer <token>（也兼容 ?token= 与网页 session cookie）
 *
 * 路由：api.php?r=<route>&...
 *   GET  r=bootstrap                      站点信息 + 当前用户
 *   GET  r=challenge                      取一道计算题（登录/注册用）
 *   POST r=login        {username,password,human,remember}
 *   POST r=register     {username,email,code,password,agree}
 *   POST r=sendcode     {email,human}
 *   POST r=logout
 *   GET  r=me
 *   GET  r=feed         ?tab=script|ask|resource&page=1
 *   GET  r=script       ?id=
 *   GET  r=thread       ?id=
 *   GET  r=resource     ?id=
 *   GET  r=search       ?q=
 *   POST r=like         {id}
 *   POST r=comment      {id,content,parent_id?}
 *   POST r=reply        {id,content}
 *   POST r=thread       {title,content,tag}
 */

require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/gc_hub.php';

if (!headers_sent()) {
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: no-store');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: Authorization, Content-Type');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
}
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

/* ============================ 基础工具 ============================ */

function api_body(): array
{
    static $in = null;
    if ($in !== null) return $in;
    $raw = (string)file_get_contents('php://input');
    $j = json_decode($raw, true);
    $in = is_array($j) ? $j : (is_array($_POST) ? $_POST : []);
    return $in;
}

function api_param(string $key, $default = '')
{
    if (array_key_exists($key, $_GET)) return $_GET[$key];
    $b = api_body();
    return $b[$key] ?? $default;
}

function api_fail(string $msg, int $code = 400, array $extra = []): never
{
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $msg] + $extra, JSON_UNESCAPED_UNICODE);
    exit;
}

function api_ok(array $data = []): never
{
    echo json_encode(['ok' => true] + $data, JSON_UNESCAPED_UNICODE);
    exit;
}

function api_tokens_schema(): void
{
    gc_ddl_exec("CREATE TABLE IF NOT EXISTS gc_app_tokens (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        token_hash TEXT NOT NULL,
        device TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
        last_used TEXT NOT NULL DEFAULT ''
    )");
    try { gc_ddl_exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_app_token ON gc_app_tokens(token_hash)"); } catch (Throwable $e) {}
    try { gc_ddl_exec("CREATE INDEX IF NOT EXISTS idx_app_token_user ON gc_app_tokens(user_id)"); } catch (Throwable $e) {}
}

function api_token(): string
{
    $h = (string)($_SERVER['HTTP_AUTHORIZATION'] ?? '');
    if ($h === '' && isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) $h = (string)$_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
    if ($h === '' && function_exists('getallheaders')) {
        foreach ((array)getallheaders() as $k => $v) {
            if (strcasecmp((string)$k, 'Authorization') === 0) { $h = (string)$v; break; }
        }
    }
    if (preg_match('/^Bearer\s+([A-Za-z0-9]{32,128})$/i', trim($h), $m)) return $m[1];
    $q = (string)($_GET['token'] ?? '');
    return preg_match('/^[A-Za-z0-9]{32,128}$/', $q) ? $q : '';
}

function api_user(): ?array
{
    static $cache = false;
    if ($cache !== false) return $cache;
    $cache = null;
    $tok = api_token();
    if ($tok !== '') {
        $st = db()->prepare('SELECT id, user_id FROM gc_app_tokens WHERE token_hash = ?');
        $st->execute([hash('sha256', $tok)]);
        $row = $st->fetch();
        if ($row) {
            $q = db()->prepare('SELECT * FROM users WHERE id = ?');
            $q->execute([(int)$row['user_id']]);
            $cache = $q->fetch() ?: null;
            try { db()->prepare('UPDATE gc_app_tokens SET last_used = ? WHERE id = ?')->execute([date('Y-m-d H:i:s'), (int)$row['id']]); } catch (Throwable $e) {}
            return $cache;
        }
    }
    // 兼容：网页已登录时（同域 cookie）也认
    return $cache = current_user();
}

function api_need_user(): array
{
    $u = api_user();
    if (!$u) api_fail('请先登录', 401, ['login' => true]);
    if (!empty($u['banned'])) api_fail('账号已被限制：' . ((string)($u['ban_reason'] ?? '') ?: '违反站内规定'), 403);
    return $u;
}

function api_user_out(?array $u): ?array
{
    if (!$u) return null;
    return [
        'id'     => (int)$u['id'],
        'name'   => (string)$u['username'],
        'email'  => (string)($u['email'] ?? ''),
        'role'   => (string)($u['role'] ?? 'user'),
        'avatar' => avatar_url((int)$u['id']),
        'banned' => (int)($u['banned'] ?? 0) === 1,
    ];
}

/** 站内相对路径 / 上传路径 → 绝对 URL */
function api_media(string $path): string
{
    $path = trim($path);
    if ($path === '') return '';
    if (preg_match('#^https?://#i', $path)) return $path;
    if (str_starts_with($path, '//')) return 'https:' . $path;
    return rtrim(BASE_URL, '/') . '/' . ltrim($path, '/');
}

function api_excerpt(string $s, int $n = 120): string
{
    $s = trim(preg_replace('/\s+/u', ' ', strip_tags($s)) ?? '');
    return mb_substr($s, 0, $n);
}

function api_items_script(array $rows): array
{
    if (!$rows) return [];
    $stats = script_stats(array_column($rows, 'id'));
    $out = [];
    foreach ($rows as $p) {
        $s = $stats[(int)$p['id']] ?? [];
        $out[] = [
            'type'    => 'script',
            'id'      => (int)$p['id'],
            'title'   => (string)$p['name'],
            'excerpt' => api_excerpt((string)$p['description']),
            'author'  => ['id' => (int)$p['owner_id'], 'name' => (string)($p['username'] ?? '')],
            'avatar'  => avatar_url((int)$p['owner_id']),
            'ago'     => gc_ago((string)$p['created_at']),
            'created_at' => (string)$p['created_at'],
            'likes'   => (int)($s['likes'] ?? 0),
            'comments'=> (int)($s['comments'] ?? 0),
            'views'   => (int)($s['views'] ?? 0),
            'pinned'  => (int)$p['pinned'] === 1,
            'image'   => api_media((string)($p['image'] ?? '')),
            'tag'     => '',
            'solved'  => false,
        ];
    }
    return $out;
}

function api_items_thread(array $rows): array
{
    $tags = gc_forum_tags();
    $out = [];
    foreach ($rows as $t) {
        $out[] = [
            'type'    => 'thread',
            'id'      => (int)$t['id'],
            'title'   => (string)$t['title'],
            'excerpt' => api_excerpt((string)$t['content']),
            'author'  => ['id' => (int)$t['owner_id'], 'name' => (string)($t['username'] ?? '')],
            'avatar'  => avatar_url((int)$t['owner_id']),
            'ago'     => gc_ago((string)($t['last_reply_at'] !== '' ? $t['last_reply_at'] : $t['created_at'])),
            'created_at' => (string)$t['created_at'],
            'likes'   => 0,
            'comments'=> (int)$t['reply_count'],
            'views'   => (int)$t['view_count'],
            'pinned'  => false,
            'image'   => '',
            'tag'     => (string)($tags[$t['tag']] ?? '其他'),
            'solved'  => (int)$t['solved'] === 1,
        ];
    }
    return $out;
}

function api_items_resource(array $rows): array
{
    $out = [];
    foreach ($rows as $r) {
        $out[] = [
            'type'    => 'resource',
            'id'      => (int)$r['id'],
            'title'   => (string)$r['title'],
            'excerpt' => api_excerpt((string)$r['description']),
            'author'  => ['id' => (int)$r['owner_id'], 'name' => (string)($r['username'] ?? '')],
            'avatar'  => avatar_url((int)$r['owner_id']),
            'ago'     => gc_ago((string)$r['created_at']),
            'created_at' => (string)$r['created_at'],
            'likes'   => 0,
            'comments'=> (int)$r['file_count'],
            'views'   => (int)$r['download_count'],
            'pinned'  => (int)$r['is_official'] === 1,
            'image'   => api_media((string)($r['cover'] ?? '')),
            'tag'     => (string)$r['category'],
            'solved'  => false,
        ];
    }
    return $out;
}

/* ============================ 路由 ============================ */

try {
    api_tokens_schema();
} catch (Throwable $e) {
    // 建表失败不阻断只读接口
}

$r = (string)($_GET['r'] ?? '');

switch ($r) {

    /* ---------------- 站点信息 ---------------- */
    case 'bootstrap': {
        $u = api_user();
        api_ok([
            'site' => [
                'name' => site_name(),
                'base' => rtrim(BASE_URL, '/'),
                'logo' => rtrim(BASE_URL, '/') . '/assets/favicon.svg',
            ],
            'user' => api_user_out($u),
            'tags' => gc_forum_tags(),
            'version' => 1,
        ]);
    }

    /* ---------------- 人机验证题 ---------------- */
    case 'challenge': {
        start_session();
        api_ok(human_challenge_make());
    }

    /* ---------------- 登录 ---------------- */
    case 'login': {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') api_fail('请用 POST 登录', 405);
        start_session();
        $name = trim((string)api_param('username'));
        $pass = (string)api_param('password');
        if ($name === '' || $pass === '') api_fail('请输入用户名和密码');

        $ipKey = 'applogin:' . client_ip();
        $uKey  = 'apploginu:' . mb_strtolower($name);
        if (rate_limited($ipKey, 15, 600) || rate_limited($uKey, 8, 600)) {
            api_fail('尝试次数过多，请 10 分钟后再试', 429);
        }
        if (!human_challenge_check((string)api_param('human'))) {
            api_fail('验证题答案错误或已过期', 400, ['challenge' => true]);
        }

        $st = db()->prepare('SELECT * FROM users WHERE username = ? OR email = ?');
        $st->execute([$name, $name]);
        $row = $st->fetch();
        if (!$row || !password_verify($pass, (string)$row['password_hash'])) {
            rate_hit($ipKey);
            rate_hit($uKey);
            api_fail('用户名或密码错误');
        }
        if (!empty($row['banned']) && (string)($row['role'] ?? '') !== 'owner') {
            api_fail('账号已被限制：' . ((string)($row['ban_reason'] ?? '') ?: '违反站内规定'), 403);
        }

        $token = bin2hex(random_bytes(32));
        db()->prepare('INSERT INTO gc_app_tokens(user_id,token_hash,device) VALUES(?,?,?)')
            ->execute([(int)$row['id'], hash('sha256', $token), mb_substr((string)api_param('device'), 0, 120)]);
        // 顺手保持网页会话，两边登录状态一致
        session_regenerate_id(true);
        $_SESSION['uid'] = (int)$row['id'];
        if ((string)api_param('remember') === '1') remember_set((int)$row['id']);

        api_ok(['token' => $token, 'user' => api_user_out($row)]);
    }

    /* ---------------- 注册：发验证码 ---------------- */
    case 'sendcode': {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') api_fail('请用 POST', 405);
        start_session();
        if (!human_challenge_check((string)api_param('human'))) api_fail('验证题答案错误或已过期', 400, ['challenge' => true]);
        $email = strtolower(trim((string)api_param('email')));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) api_fail('邮箱格式不正确');
        if (rate_limited('sendcode:' . client_ip(), 5, 3600)) api_fail('发送次数过多，请稍后再试', 429);
        $st = db()->prepare('SELECT 1 FROM users WHERE email = ?');
        $st->execute([$email]);
        if ($st->fetchColumn()) api_fail('该邮箱已注册');
        $st = db()->prepare('SELECT 1 FROM email_codes WHERE email = ? AND sent_at > ?');
        $st->execute([$email, time() - 60]);
        if ($st->fetchColumn()) api_fail('发送太频繁，请 60 秒后再试');
        if (!smtp_configured()) api_fail('站点邮件服务未配置，请到网页端注册');

        rate_hit('sendcode:' . client_ip());
        $code = email_code_create($email);
        $vars = ['site' => site_name(), 'code' => $code, 'email' => $email, 'time' => '10'];
        $subject = mail_template_render(site_setting('mail_subject', '{site} 注册验证码'), $vars);
        $body = mail_template_render(site_setting('mail_body', "你好！\n\n你的 {site} 注册验证码是：{code}\n\n验证码 {time} 分钟内有效，请勿泄露给他人。"), $vars);
        $err = null;
        if (!send_mail($email, $subject, $body, $err)) {
            try { db()->prepare('DELETE FROM email_codes WHERE email = ?')->execute([$email]); } catch (Throwable $e) {}
            api_fail('邮件发送失败，请稍后重试', 500);
        }
        api_ok(['sent' => true]);
    }

    /* ---------------- 注册：提交 ---------------- */
    case 'register': {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') api_fail('请用 POST', 405);
        start_session();
        if (rate_limited('appreg:' . client_ip(), 10, 3600)) api_fail('操作过于频繁，请稍后再试', 429);
        rate_hit('appreg:' . client_ip());
        $username = trim((string)api_param('username'));
        $email = strtolower(trim((string)api_param('email')));
        $code = trim((string)api_param('code'));
        $pass = (string)api_param('password');
        if (!preg_match('/^[\w\x{4e00}-\x{9fa5}]{2,20}$/u', $username)) api_fail('用户名需 2-20 位（字母数字下划线或中文）');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) api_fail('邮箱格式不正确');
        if (strlen($pass) < 6) api_fail('密码至少 6 位');
        if ((string)api_param('agree') !== '1') api_fail('请先阅读并同意《用户条款与免责声明》');
        if (!email_code_verify($email, $code)) api_fail('验证码错误或已过期');
        $st = db()->prepare('SELECT 1 FROM users WHERE username = ? OR email = ?');
        $st->execute([$username, $email]);
        if ($st->fetchColumn()) api_fail('用户名或邮箱已被使用');
        $role = (int)db()->query('SELECT COUNT(*) FROM users')->fetchColumn() === 0 ? 'owner' : 'user';
        db()->prepare('INSERT INTO users(username,email,password_hash,role) VALUES(?,?,?,?)')
            ->execute([$username, $email, password_hash($pass, PASSWORD_DEFAULT), $role]);
        $uid = (int)db()->lastInsertId();
        $token = bin2hex(random_bytes(32));
        db()->prepare('INSERT INTO gc_app_tokens(user_id,token_hash,device) VALUES(?,?,?)')
            ->execute([$uid, hash('sha256', $token), mb_substr((string)api_param('device'), 0, 120)]);
        session_regenerate_id(true);
        $_SESSION['uid'] = $uid;
        $q = db()->prepare('SELECT * FROM users WHERE id = ?');
        $q->execute([$uid]);
        api_ok(['token' => $token, 'user' => api_user_out($q->fetch() ?: null)]);
    }

    /* ---------------- 退出 ---------------- */
    case 'logout': {
        $tok = api_token();
        if ($tok !== '') {
            try { db()->prepare('DELETE FROM gc_app_tokens WHERE token_hash = ?')->execute([hash('sha256', $tok)]); } catch (Throwable $e) {}
        }
        start_session();
        remember_clear();
        $_SESSION = [];
        @session_destroy();
        api_ok();
    }

    /* ---------------- 我 ---------------- */
    case 'me': {
        $u = api_need_user();
        $uid = (int)$u['id'];
        $counts = ['scripts' => 0, 'threads' => 0];
        try {
            $q = db()->prepare('SELECT COUNT(*) FROM scripts WHERE owner_id = ?');
            $q->execute([$uid]);
            $counts['scripts'] = (int)$q->fetchColumn();
            $q = db()->prepare('SELECT COUNT(*) FROM gc_forum_threads WHERE owner_id = ? AND status = ?');
            $q->execute([$uid, 'published']);
            $counts['threads'] = (int)$q->fetchColumn();
        } catch (Throwable $e) {}
        api_ok(['user' => api_user_out($u), 'counts' => $counts]);
    }

    /* ---------------- 列表 ---------------- */
    case 'feed': {
        $tab = (string)api_param('tab', 'script');
        if (!in_array($tab, ['script', 'ask', 'resource'], true)) $tab = 'script';
        $page = max(1, (int)api_param('page', 1));
        $per = 20;
        $off = ($page - 1) * $per;
        $items = [];
        $more = false;

        if ($tab === 'script') {
            $total = (int)db()->query("SELECT COUNT(*) FROM scripts s JOIN users u ON u.id = s.owner_id WHERE s.visibility = 'public'")->fetchColumn();
            $st = db()->prepare("SELECT s.*, u.username FROM scripts s JOIN users u ON u.id = s.owner_id
                                 WHERE s.visibility = 'public' ORDER BY s.pinned DESC, s.id DESC LIMIT ? OFFSET ?");
            $st->bindValue(1, $per, PDO::PARAM_INT);
            $st->bindValue(2, $off, PDO::PARAM_INT);
            $st->execute();
            $items = api_items_script($st->fetchAll() ?: []);
            $more = $page * $per < $total;
        } elseif ($tab === 'ask') {
            $total = (int)db()->query("SELECT COUNT(*) FROM gc_forum_threads WHERE status = 'published'")->fetchColumn();
            $st = db()->prepare("SELECT t.*, u.username FROM gc_forum_threads t LEFT JOIN users u ON u.id = t.owner_id
                                 WHERE t.status = 'published'
                                 ORDER BY CASE WHEN t.last_reply_at > t.created_at THEN t.last_reply_at ELSE t.created_at END DESC, t.id DESC
                                 LIMIT ? OFFSET ?");
            $st->bindValue(1, $per, PDO::PARAM_INT);
            $st->bindValue(2, $off, PDO::PARAM_INT);
            $st->execute();
            $items = api_items_thread($st->fetchAll() ?: []);
            $more = $page * $per < $total;
        } else {
            $total = (int)db()->query("SELECT COUNT(*) FROM gc_resources WHERE status = 'published' AND visibility = 'public'")->fetchColumn();
            $st = db()->prepare("SELECT r.*, u.username FROM gc_resources r LEFT JOIN users u ON u.id = r.owner_id
                                 WHERE r.status = 'published' AND r.visibility = 'public'
                                 ORDER BY r.is_official DESC, r.id DESC LIMIT ? OFFSET ?");
            $st->bindValue(1, $per, PDO::PARAM_INT);
            $st->bindValue(2, $off, PDO::PARAM_INT);
            $st->execute();
            $items = api_items_resource($st->fetchAll() ?: []);
            $more = $page * $per < $total;
        }

        api_ok(['tab' => $tab, 'page' => $page, 'more' => $more, 'items' => $items]);
    }

    /* ---------------- 脚本详情 ---------------- */
    case 'script': {
        $id = (int)api_param('id');
        $st = db()->prepare('SELECT s.*, u.username FROM scripts s JOIN users u ON u.id = s.owner_id WHERE s.id = ?');
        $st->execute([$id]);
        $p = $st->fetch();
        if (!$p) api_fail('内容不存在', 404);
        $u = api_user();
        $isOwner = $u && ((int)$u['id'] === (int)$p['owner_id'] || is_admin());
        if ((string)$p['visibility'] !== 'public' && !$isOwner) api_fail('内容不存在', 404);

        $sourceOpen = ((string)($p['source_visibility'] ?? 'public') === 'public') || $isOwner;
        $src = '';
        if ($sourceOpen) {
            $orig = (string)($p['original_content'] ?? '');
            $src = $orig !== '' ? $orig : (string)$p['content'];
        }
        $cs = db()->prepare('SELECT c.*, u.username FROM comments c LEFT JOIN users u ON u.id = c.user_id
                             WHERE c.script_id = ? ORDER BY c.id ASC LIMIT 200');
        $cs->execute([$id]);
        $comments = [];
        foreach (($cs->fetchAll() ?: []) as $c) {
            $comments[] = [
                'id' => (int)$c['id'],
                'name' => (string)($c['username'] ?? '已注销'),
                'avatar' => avatar_url((int)$c['user_id']),
                'content' => (string)$c['content'],
                'ago' => gc_ago((string)$c['created_at']),
            ];
        }
        $s = script_stats([$id])[$id] ?? [];
        api_ok([
            'item' => api_items_script([$p])[0],
            'content' => $src,
            'locked' => !$sourceOpen,
            'description' => (string)$p['description'],
            'liked' => $u ? user_liked($id, (int)$u['id']) : false,
            'comments' => $comments,
            'total_comments' => (int)($s['comments'] ?? count($comments)),
        ]);
    }

    /* ---------------- 提问详情 ---------------- */
    case 'thread': {
        $id = (int)api_param('id');
        $t = gc_forum_thread($id);
        if (!$t || (string)$t['status'] !== 'published') api_fail('帖子不存在或已删除', 404);
        try { db()->prepare('UPDATE gc_forum_threads SET view_count = view_count + 1 WHERE id = ?')->execute([$id]); } catch (Throwable $e) {}
        $posts = [];
        foreach ((gc_forum_posts($id) ?: []) as $p) {
            $posts[] = [
                'id' => (int)$p['id'],
                'name' => (string)($p['username'] ?? '已注销'),
                'avatar' => avatar_url((int)$p['owner_id']),
                'content' => (string)$p['content'],
                'ago' => gc_ago((string)$p['created_at']),
                'accepted' => (int)$p['is_accepted'] === 1,
            ];
        }
        $tags = gc_forum_tags();
        api_ok([
            'item' => api_items_thread([$t])[0],
            'content' => (string)$t['content'],
            'tag_name' => (string)($tags[$t['tag']] ?? '其他'),
            'posts' => $posts,
        ]);
    }

    /* ---------------- 资源详情 ---------------- */
    case 'resource': {
        $id = (int)api_param('id');
        $st = db()->prepare('SELECT r.*, u.username FROM gc_resources r LEFT JOIN users u ON u.id = r.owner_id WHERE r.id = ?');
        $st->execute([$id]);
        $res = $st->fetch();
        if (!$res || (string)$res['status'] !== 'published') api_fail('资源不存在', 404);
        $u = api_user();
        if ((string)$res['visibility'] !== 'public' && !($u && (int)$u['id'] === (int)$res['owner_id'])) api_fail('资源不存在', 404);
        $fs = db()->prepare('SELECT * FROM gc_resource_files WHERE resource_id = ? ORDER BY sort ASC, id ASC');
        $fs->execute([$id]);
        $files = [];
        foreach (($fs->fetchAll() ?: []) as $f) {
            $files[] = [
                'id' => (int)$f['id'],
                'name' => (string)$f['name'],
                'size' => (int)$f['size'],
                'size_text' => gc_size_text((int)$f['size']),
                'downloads' => (int)$f['download_count'],
                'url' => rtrim(BASE_URL, '/') . '/download.php?id=' . (int)$f['id'],
            ];
        }
        api_ok([
            'item' => api_items_resource([$res])[0],
            'description' => (string)$res['description'],
            'files' => $files,
            'tags' => array_values(array_filter(array_map('trim', explode(',', (string)$res['tags'])))),
        ]);
    }

    /* ---------------- 搜索 ---------------- */
    case 'search': {
        $q = trim((string)api_param('q'));
        if (mb_strlen($q) < 1) api_ok(['items' => []]);
        $like = '%' . $q . '%';
        $items = [];

        $st = db()->prepare("SELECT s.*, u.username FROM scripts s JOIN users u ON u.id = s.owner_id
                             WHERE s.visibility = 'public' AND (s.name LIKE ? OR s.description LIKE ?)
                             ORDER BY s.id DESC LIMIT 20");
        $st->execute([$like, $like]);
        $items = array_merge($items, api_items_script($st->fetchAll() ?: []));

        $st = db()->prepare("SELECT t.*, u.username FROM gc_forum_threads t LEFT JOIN users u ON u.id = t.owner_id
                             WHERE t.status = 'published' AND (t.title LIKE ? OR t.content LIKE ?)
                             ORDER BY t.id DESC LIMIT 20");
        $st->execute([$like, $like]);
        $items = array_merge($items, api_items_thread($st->fetchAll() ?: []));

        $st = db()->prepare("SELECT r.*, u.username FROM gc_resources r LEFT JOIN users u ON u.id = r.owner_id
                             WHERE r.status = 'published' AND r.visibility = 'public' AND (r.title LIKE ? OR r.description LIKE ?)
                             ORDER BY r.id DESC LIMIT 20");
        $st->execute([$like, $like]);
        $items = array_merge($items, api_items_resource($st->fetchAll() ?: []));

        api_ok(['items' => $items, 'q' => $q]);
    }

    /* ---------------- 点赞 ---------------- */
    case 'like': {
        $u = api_need_user();
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') api_fail('请用 POST', 405);
        $id = (int)api_param('id');
        $st = db()->prepare('SELECT * FROM scripts WHERE id = ?');
        $st->execute([$id]);
        $p = $st->fetch();
        if (!$p) api_fail('内容不存在', 404);
        $uid = (int)$u['id'];
        if (user_liked($id, $uid)) {
            db()->prepare('DELETE FROM script_likes WHERE script_id = ? AND user_id = ?')->execute([$id, $uid]);
        } else {
            db()->prepare('INSERT INTO script_likes(script_id,user_id) VALUES(?,?)')->execute([$id, $uid]);
            if ((int)$p['owner_id'] !== $uid) {
                try {
                    require_once __DIR__ . '/notify_service.php';
                    gc_send_notification((int)$p['owner_id'], 'likes', '帖子收到点赞', (string)$p['name'], '/post.php?id=' . $id);
                } catch (Throwable $e) {}
            }
        }
        api_ok(['liked' => user_liked($id, $uid), 'likes' => like_count($id)]);
    }

    /* ---------------- 评论（脚本） ---------------- */
    case 'comment': {
        $u = api_need_user();
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') api_fail('请用 POST', 405);
        $id = (int)api_param('id');
        $c = trim((string)api_param('content'));
        $st = db()->prepare('SELECT * FROM scripts WHERE id = ?');
        $st->execute([$id]);
        $p = $st->fetch();
        if (!$p) api_fail('内容不存在', 404);
        if ($c === '' || mb_strlen($c) > 1000) api_fail('评论内容需 1-1000 字');
        if (rate_limited('cmt:' . (int)$u['id'], 10, 60)) api_fail('评论太快了，稍等一会儿', 429);
        rate_hit('cmt:' . (int)$u['id']);
        $pid = (int)api_param('parent_id', 0);
        db()->prepare('INSERT INTO comments(script_id,user_id,content,parent_id) VALUES(?,?,?,?)')
            ->execute([$id, (int)$u['id'], $c, $pid > 0 ? $pid : 0]);
        if ((int)$p['owner_id'] !== (int)$u['id']) {
            try {
                require_once __DIR__ . '/notify_service.php';
                gc_send_notification((int)$p['owner_id'], 'comments', '帖子收到评论', mb_substr($c, 0, 90), '/post.php?id=' . $id);
            } catch (Throwable $e) {}
        }
        api_ok(['comments' => gc_comment_count($id)]);
    }

    /* ---------------- 回复（提问） ---------------- */
    case 'reply': {
        $u = api_need_user();
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') api_fail('请用 POST', 405);
        $id = (int)api_param('id');
        $body = trim((string)api_param('content'));
        $t = gc_forum_thread($id);
        if (!$t || (string)$t['status'] !== 'published') api_fail('帖子不存在', 404);
        if (mb_strlen($body) < 2) api_fail('回复内容太短了');
        if (mb_strlen($body) > 8000) api_fail('回复最长 8000 字');
        $last = db()->prepare('SELECT created_at FROM gc_forum_posts WHERE thread_id=? AND owner_id=? ORDER BY id DESC LIMIT 1');
        $last->execute([$id, (int)$u['id']]);
        $lastAt = (string)($last->fetchColumn() ?: '');
        if ($lastAt !== '' && time() - (int)strtotime($lastAt) < 60) api_fail('发得太快了，等一分钟再发', 429);
        db()->prepare('INSERT INTO gc_forum_posts(thread_id,owner_id,content) VALUES(?,?,?)')
            ->execute([$id, (int)$u['id'], $body]);
        db()->prepare('UPDATE gc_forum_threads SET reply_count = reply_count + 1, last_reply_at = ? WHERE id = ?')
            ->execute([date('Y-m-d H:i:s'), $id]);
        api_ok(['id' => (int)db()->lastInsertId()]);
    }

    /* ---------------- 发提问帖 ---------------- */
    case 'newthread': {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') api_fail('请用 POST', 405);
        $u = api_need_user();
        $title = trim((string)api_param('title'));
        $content = trim((string)api_param('content'));
        $tag = (string)api_param('tag', 'other');
        $tags = gc_forum_tags();
        if (!isset($tags[$tag])) $tag = 'other';
        if (mb_strlen($title) < 4) api_fail('标题至少 4 个字');
        if (mb_strlen($title) > 120) api_fail('标题最长 120 字');
        if (mb_strlen($content) < 6) api_fail('内容至少 6 个字');
        if (mb_strlen($content) > 20000) api_fail('内容太长');
        if (rate_limited('thr:' . (int)$u['id'], 5, 600)) api_fail('发帖太频繁，请稍后再试', 429);
        rate_hit('thr:' . (int)$u['id']);
        db()->prepare('INSERT INTO gc_forum_threads(owner_id,title,content,tag,last_reply_at) VALUES(?,?,?,?,?)')
            ->execute([(int)$u['id'], $title, $content, $tag, date('Y-m-d H:i:s')]);
        api_ok(['id' => (int)db()->lastInsertId()]);
    }

    default:
        api_fail('未知接口', 404, ['routes' => ['bootstrap','challenge','login','register','sendcode','logout','me','feed','script','thread','resource','search','like','comment','reply','newthread']]);
}
