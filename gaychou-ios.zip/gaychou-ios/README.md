# gayChou for iOS

gayChou 网站的**原生 iOS 客户端**（SwiftUI），与网站共用同一数据库：登录/注册、动态、评论、点赞全部实时同步，不存在第二份数据。

- 最低支持 iOS 16.0，仅竖屏 iPhone
- 通过 GitHub Actions 在云端构建，产出**未签名 ipa**（自签后即可安装）
- 后端只有一个文件 `server/api.php`，与网站同域部署，零数据库改动

## 功能

| 模块 | 说明 |
|---|---|
| 首页 | 脚本 / 提问 / 资源三个分区，下拉刷新 + 滚动自动加载 |
| 详情 | 脚本（源码复制 / 点赞 / 评论）、提问（回复）、资源（文件下载） |
| 搜索 | 全站脚本、提问、资源统一搜索 |
| 发布 | 直接发提问帖（脚本与资源因涉及上传，引导到网页端） |
| 我的 | 登录 / 注册、发帖统计、跳转我的脚本、消息通知等网页页 |
| 验证 | 登录与注册沿用站点的计算题人机验证 + 邮箱验证码，复用同一套限流 |

账号与网页**完全通用**：App 登录走站点 `users` 表同一个 `password_hash`，密码改一处两边同时生效。

## 目录结构

```
gaychou-ios/
├── project.yml                  # XcodeGen 工程描述（CI 用它生成 xcodeproj）
├── Gaychou/
│   ├── Sources/
│   │   ├── App/RootView.swift       # 根容器 + 自定义玻璃底栏
│   │   ├── Core/                    # APIClient / Models / Session / Theme
│   │   ├── Views/                   # 首页、详情、登录、发布、搜索、我的
│   │   └── Components/FeedRow.swift # 列表卡片
│   └── Resources/                   # Info.plist / 图标
├── server/api.php               # 后端 JSON API（部署到网站根目录）
└── .github/workflows/ios.yml    # 云端构建
```

## 后端：api.php

已支持接口（全部与站点共用数据库，走既有 `lib.php` 数据层）：

```
GET  r=bootstrap / challenge / feed / script / thread / resource / search / me
POST r=login / register / sendcode / logout / like / comment / reply / newthread
```

- 鉴权：登录后签发 64 位随机 token（库内只存 sha256），请求带 `Authorization: Bearer <token>`
- 建表：自动补一张 `gc_app_tokens` 表，其余全部复用现有表，**不改动任何旧数据**
- 安全：沿用站内 `rate_limited` 限流、封禁检查、源码可见性（`source_visibility`）判断

## 云端构建出 ipa

1. 在 GitHub 新建仓库，把本目录推上去：

   ```bash
   git init && git add -A && git commit -m "gayChou iOS"
   git remote add origin https://github.com/<你的用户名>/gaychou-ios.git
   git push -u origin main
   ```

2. 打开仓库 **Actions** 页，等 `Build iOS IPA` 跑绿（约 3~5 分钟）
3. 进该次运行，在 **Artifacts** 下载 `gayChou-unsigned-ipa`，里面就是 **未签名 ipa**

## 安装到手机（自签）

未签名 ipa 需要用你的 Apple ID 签名后安装，任选其一：

| 工具 | 平台 | 说明 |
|---|---|---|
| Sideloadly | Windows / macOS | 插数据线，拖入 ipa，填 Apple ID 点 Start，7 天有效 |
| AltStore | iPhone | 装一次 AltServer，之后手机上可自动续签 |
| 爱思助手 | Windows / macOS | 导入 ipa → 自签安装，最省事 |

有付费开发者账号（$99/年）时，可把工作流里的 `CODE_SIGNING_ALLOWED=NO` 去掉并配置证书 Secrets，直接产出可安装的签名包；个人使用推荐直接 Sideloadly。

## 常改配置

| 要改什么 | 位置 |
|---|---|
| 站点域名 | `Gaychou/Sources/Core/APIClient.swift` 的 `baseURL` 与 `ProfileView.swift` 的 `base` |
| 应用名 / 图标 | `Gaychou/Resources/`（Info.plist、Assets.xcassets/AppIcon） |
| 版本号 | `project.yml` 的 `MARKETING_VERSION` |
| 首页菜单跳转的网页链接 | `ProfileView.swift` 的 `menuCard` |

## 已知边界

- 脚本源码遵循站点 `source_visibility`：作者未公开时 App 显示"作者未公开源码"
- 付费脚本的购买/下单流程在网页端完成，App 只读展示
- 上传封面 / 多文件资源发布仍在网页端（iOS 端不做文件上传，减少权限申请）
